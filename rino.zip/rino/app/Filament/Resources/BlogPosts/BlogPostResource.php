<?php

namespace App\Filament\Resources\BlogPosts;

use App\Filament\Resources\BlogPosts\Pages\CreateBlogPost;
use App\Filament\Resources\BlogPosts\Pages\EditBlogPost;
use App\Filament\Resources\BlogPosts\Pages\ListBlogPosts;
use App\Filament\Resources\BlogPosts\Schemas\BlogPostForm;
use App\Filament\Resources\BlogPosts\Tables\BlogPostsTable;
use App\Models\BlogPost;
use BackedEnum;
use Filament\Resources\Resource;
use Filament\Schemas\Schema;
use Filament\Tables\Table;
use UnitEnum;

class BlogPostResource extends Resource
{
    protected static ?string $model =
        BlogPost::class;

    protected static string|UnitEnum|null $navigationGroup =
        'Content';

    protected static string|BackedEnum|null $navigationIcon =
        'heroicon-o-document-text';

    protected static ?string $navigationLabel =
        'Blog Posts';

    protected static ?string $modelLabel =
        'Blog Post';

    protected static ?string $pluralModelLabel =
        'Blog Posts';

    protected static ?string $recordTitleAttribute =
        'title';

    protected static bool $shouldRegisterNavigation =
        false;

    public static function form(
        Schema $schema
    ): Schema {
        return BlogPostForm::configure(
            $schema
        );
    }

    public static function table(
        Table $table
    ): Table {
        return BlogPostsTable::configure(
            $table
        );
    }

    public static function getRelations(): array
    {
        return [];
    }

    public static function getPages(): array
    {
        return [
            'index' =>
                ListBlogPosts::route(
                    '/'
                ),

            'create' =>
                CreateBlogPost::route(
                    '/create'
                ),

            'edit' =>
                EditBlogPost::route(
                    '/{record}/edit'
                ),
        ];
    }
}