<?php

namespace App\Filament\Resources\BlogPosts\Pages;

use App\Filament\Resources\BlogPosts\BlogPostResource;
use Filament\Resources\Pages\CreateRecord;

class CreateBlogPost extends CreateRecord
{
    protected static string $resource =
        BlogPostResource::class;

    protected function getRedirectUrl(): string
    {
        return \App\Filament\Pages\Blogs::getUrl();
    }
}