@php
    use App\Support\LocationPresets;

    $mapLocations =
        is_array($locations ?? null)
            ? $locations
            : [];
@endphp

<div
    class="rino-world-map"
    data-rino-world-map
>
<svg viewBox="0 0 126 60" xmlns="http://www.w3.org/2000/svg" style="background-color:transparent" class="rino-world-svg" preserveAspectRatio="xMidYMid meet">
  <circle r=".22" fill="currentColor"/>
  <circle cx="8" r=".22" fill="currentColor"/>
  <circle cx="22" r=".22" fill="currentColor"/>
  <circle cx="23" r=".22" fill="currentColor"/>
  <circle cx="24" r=".22" fill="currentColor"/>
  <circle cx="25" r=".22" fill="currentColor"/>
  <circle cx="26" r=".22" fill="currentColor"/>
  <circle cx="30" r=".22" fill="currentColor"/>
  <circle cx="32" r=".22" fill="currentColor"/>
  <circle cx="33" r=".22" fill="currentColor"/>
  <circle cx="34" r=".22" fill="currentColor"/>
  <circle cx="35" r=".22" fill="currentColor"/>
  <circle cx="36" r=".22" fill="currentColor"/>
  <circle cx="37" r=".22" fill="currentColor"/>
  <circle cx="45" r=".22" fill="currentColor"/>
  <circle cx="46" r=".22" fill="currentColor"/>
  <circle cx="47" r=".22" fill="currentColor"/>
  <circle cx="48" r=".22" fill="currentColor"/>
  <circle cx="49" r=".22" fill="currentColor"/>
  <circle cx="50" r=".22" fill="currentColor"/>
  <circle cx="51" r=".22" fill="currentColor"/>
  <circle cx="52" r=".22" fill="currentColor"/>
  <circle cx="53" r=".22" fill="currentColor"/>
  <circle cx="54" r=".22" fill="currentColor"/>
  <circle cx="55" r=".22" fill="currentColor"/>
  <circle cx="72" r=".22" fill="currentColor"/>
  <circle cx="73" r=".22" fill="currentColor"/>
  <circle cx="82" r=".22" fill="currentColor"/>
  <circle cx="83" r=".22" fill="currentColor"/>
  <circle cx="87" r=".22" fill="currentColor"/>
  <circle cx="88" r=".22" fill="currentColor"/>
  <circle cx="89" r=".22" fill="currentColor"/>
  <circle cx="90" r=".22" fill="currentColor"/>
  <circle cx="91" r=".22" fill="currentColor"/>
  <circle cx="92" r=".22" fill="currentColor"/>
  <circle cx="93" r=".22" fill="currentColor"/>
  <circle cx="94" r=".22" fill="currentColor"/>
  <circle cx="95" r=".22" fill="currentColor"/>
  <circle cx="96" r=".22" fill="currentColor"/>
  <circle cx="97" r=".22" fill="currentColor"/>
  <circle cx="98" r=".22" fill="currentColor"/>
  <circle cx="99" r=".22" fill="currentColor"/>
  <circle cx="100" r=".22" fill="currentColor"/>
  <circle cx="101" r=".22" fill="currentColor"/>
  <circle cx="102" r=".22" fill="currentColor"/>
  <circle cx="103" r=".22" fill="currentColor"/>
  <circle cx="104" r=".22" fill="currentColor"/>
  <circle cx="105" r=".22" fill="currentColor"/>
  <circle cx="106" r=".22" fill="currentColor"/>
  <circle cx="107" r=".22" fill="currentColor"/>
  <circle cx="108" r=".22" fill="currentColor"/>
  <circle cx="110" r=".22" fill="currentColor"/>
  <circle cx="111" r=".22" fill="currentColor"/>
  <circle cx="112" r=".22" fill="currentColor"/>
  <circle cx="113" r=".22" fill="currentColor"/>
  <circle cx="114" r=".22" fill="currentColor"/>
  <circle cx="115" r=".22" fill="currentColor"/>
  <circle cx="116" r=".22" fill="currentColor"/>
  <circle cx="6" cy="1" r=".22" fill="currentColor"/>
  <circle cx="7" cy="1" r=".22" fill="currentColor"/>
  <circle cx="8" cy="1" r=".22" fill="currentColor"/>
  <circle cx="9" cy="1" r=".22" fill="currentColor"/>
  <circle cx="10" cy="1" r=".22" fill="currentColor"/>
  <circle cx="11" cy="1" r=".22" fill="currentColor"/>
  <circle cx="17" cy="1" r=".22" fill="currentColor"/>
  <circle cx="18" cy="1" r=".22" fill="currentColor"/>
  <circle cx="22" cy="1" r=".22" fill="currentColor"/>
  <circle cx="23" cy="1" r=".22" fill="currentColor"/>
  <circle cx="24" cy="1" r=".22" fill="currentColor"/>
  <circle cx="25" cy="1" r=".22" fill="currentColor"/>
  <circle cx="26" cy="1" r=".22" fill="currentColor"/>
  <circle cx="27" cy="1" r=".22" fill="currentColor"/>
  <circle cx="30" cy="1" r=".22" fill="currentColor"/>
  <circle cx="33" cy="1" r=".22" fill="currentColor"/>
  <circle cx="34" cy="1" r=".22" fill="currentColor"/>
  <circle cx="35" cy="1" r=".22" fill="currentColor"/>
  <circle cx="36" cy="1" r=".22" fill="currentColor"/>
  <circle cx="37" cy="1" r=".22" fill="currentColor"/>
  <circle cx="38" cy="1" r=".22" fill="currentColor"/>
  <circle cx="39" cy="1" r=".22" fill="currentColor"/>
  <circle cx="44" cy="1" r=".22" fill="currentColor"/>
  <circle cx="45" cy="1" r=".22" fill="currentColor"/>
  <circle cx="46" cy="1" r=".22" fill="currentColor"/>
  <circle cx="47" cy="1" r=".22" fill="currentColor"/>
  <circle cx="48" cy="1" r=".22" fill="currentColor"/>
  <circle cx="49" cy="1" r=".22" fill="currentColor"/>
  <circle cx="50" cy="1" r=".22" fill="currentColor"/>
  <circle cx="51" cy="1" r=".22" fill="currentColor"/>
  <circle cx="52" cy="1" r=".22" fill="currentColor"/>
  <circle cx="53" cy="1" r=".22" fill="currentColor"/>
  <circle cx="54" cy="1" r=".22" fill="currentColor"/>
  <circle cx="55" cy="1" r=".22" fill="currentColor"/>
  <circle cx="71" cy="1" r=".22" fill="currentColor"/>
  <circle cx="72" cy="1" r=".22" fill="currentColor"/>
  <circle cx="73" cy="1" r=".22" fill="currentColor"/>
  <circle cx="87" cy="1" r=".22" fill="currentColor"/>
  <circle cx="88" cy="1" r=".22" fill="currentColor"/>
  <circle cx="90" cy="1" r=".22" fill="currentColor"/>
  <circle cx="91" cy="1" r=".22" fill="currentColor"/>
  <circle cx="92" cy="1" r=".22" fill="currentColor"/>
  <circle cx="93" cy="1" r=".22" fill="currentColor"/>
  <circle cx="94" cy="1" r=".22" fill="currentColor"/>
  <circle cx="95" cy="1" r=".22" fill="currentColor"/>
  <circle cx="96" cy="1" r=".22" fill="currentColor"/>
  <circle cx="97" cy="1" r=".22" fill="currentColor"/>
  <circle cx="98" cy="1" r=".22" fill="currentColor"/>
  <circle cx="99" cy="1" r=".22" fill="currentColor"/>
  <circle cx="100" cy="1" r=".22" fill="currentColor"/>
  <circle cx="101" cy="1" r=".22" fill="currentColor"/>
  <circle cx="102" cy="1" r=".22" fill="currentColor"/>
  <circle cx="103" cy="1" r=".22" fill="currentColor"/>
  <circle cx="104" cy="1" r=".22" fill="currentColor"/>
  <circle cx="105" cy="1" r=".22" fill="currentColor"/>
  <circle cx="106" cy="1" r=".22" fill="currentColor"/>
  <circle cx="107" cy="1" r=".22" fill="currentColor"/>
  <circle cx="108" cy="1" r=".22" fill="currentColor"/>
  <circle cx="109" cy="1" r=".22" fill="currentColor"/>
  <circle cx="110" cy="1" r=".22" fill="currentColor"/>
  <circle cx="111" cy="1" r=".22" fill="currentColor"/>
  <circle cx="112" cy="1" r=".22" fill="currentColor"/>
  <circle cx="113" cy="1" r=".22" fill="currentColor"/>
  <circle cx="114" cy="1" r=".22" fill="currentColor"/>
  <circle cx="115" cy="1" r=".22" fill="currentColor"/>
  <circle cx="116" cy="1" r=".22" fill="currentColor"/>
  <circle cx="117" cy="1" r=".22" fill="currentColor"/>
  <circle cx="118" cy="1" r=".22" fill="currentColor"/>
  <circle cx="119" cy="1" r=".22" fill="currentColor"/>
  <circle cx="123" cy="1" r=".22" fill="currentColor"/>
  <circle cx="6" cy="2" r=".22" fill="currentColor"/>
  <circle cx="7" cy="2" r=".22" fill="currentColor"/>
  <circle cx="8" cy="2" r=".22" fill="currentColor"/>
  <circle cx="9" cy="2" r=".22" fill="currentColor"/>
  <circle cx="10" cy="2" r=".22" fill="currentColor"/>
  <circle cx="11" cy="2" r=".22" fill="currentColor"/>
  <circle cx="12" cy="2" r=".22" fill="currentColor"/>
  <circle cx="13" cy="2" r=".22" fill="currentColor"/>
  <circle cx="14" cy="2" r=".22" fill="currentColor"/>
  <circle cx="16" cy="2" r=".22" fill="currentColor"/>
  <circle cx="17" cy="2" r=".22" fill="currentColor"/>
  <circle cx="18" cy="2" r=".22" fill="currentColor"/>
  <circle cx="19" cy="2" r=".22" fill="currentColor"/>
  <circle cx="20" cy="2" r=".22" fill="currentColor"/>
  <circle cx="21" cy="2" r=".22" fill="currentColor"/>
  <circle cx="23" cy="2" r=".22" fill="currentColor"/>
  <circle cx="24" cy="2" r=".22" fill="currentColor"/>
  <circle cx="25" cy="2" r=".22" fill="currentColor"/>
  <circle cx="26" cy="2" r=".22" fill="currentColor"/>
  <circle cx="27" cy="2" r=".22" fill="currentColor"/>
  <circle cx="29" cy="2" r=".22" fill="currentColor"/>
  <circle cx="30" cy="2" r=".22" fill="currentColor"/>
  <circle cx="31" cy="2" r=".22" fill="currentColor"/>
  <circle cx="33" cy="2" r=".22" fill="currentColor"/>
  <circle cx="34" cy="2" r=".22" fill="currentColor"/>
  <circle cx="37" cy="2" r=".22" fill="currentColor"/>
  <circle cx="38" cy="2" r=".22" fill="currentColor"/>
  <circle cx="39" cy="2" r=".22" fill="currentColor"/>
  <circle cx="45" cy="2" r=".22" fill="currentColor"/>
  <circle cx="46" cy="2" r=".22" fill="currentColor"/>
  <circle cx="47" cy="2" r=".22" fill="currentColor"/>
  <circle cx="48" cy="2" r=".22" fill="currentColor"/>
  <circle cx="49" cy="2" r=".22" fill="currentColor"/>
  <circle cx="50" cy="2" r=".22" fill="currentColor"/>
  <circle cx="51" cy="2" r=".22" fill="currentColor"/>
  <circle cx="52" cy="2" r=".22" fill="currentColor"/>
  <circle cx="53" cy="2" r=".22" fill="currentColor"/>
  <circle cx="70" cy="2" r=".22" fill="currentColor"/>
  <circle cx="71" cy="2" r=".22" fill="currentColor"/>
  <circle cx="72" cy="2" r=".22" fill="currentColor"/>
  <circle cx="73" cy="2" r=".22" fill="currentColor"/>
  <circle cx="74" cy="2" r=".22" fill="currentColor"/>
  <circle cx="75" cy="2" r=".22" fill="currentColor"/>
  <circle cx="85" cy="2" r=".22" fill="currentColor"/>
  <circle cx="86" cy="2" r=".22" fill="currentColor"/>
  <circle cx="88" cy="2" r=".22" fill="currentColor"/>
  <circle cx="90" cy="2" r=".22" fill="currentColor"/>
  <circle cx="91" cy="2" r=".22" fill="currentColor"/>
  <circle cx="92" cy="2" r=".22" fill="currentColor"/>
  <circle cx="93" cy="2" r=".22" fill="currentColor"/>
  <circle cx="94" cy="2" r=".22" fill="currentColor"/>
  <circle cx="95" cy="2" r=".22" fill="currentColor"/>
  <circle cx="96" cy="2" r=".22" fill="currentColor"/>
  <circle cx="97" cy="2" r=".22" fill="currentColor"/>
  <circle cx="98" cy="2" r=".22" fill="currentColor"/>
  <circle cx="99" cy="2" r=".22" fill="currentColor"/>
  <circle cx="100" cy="2" r=".22" fill="currentColor"/>
  <circle cx="101" cy="2" r=".22" fill="currentColor"/>
  <circle cx="102" cy="2" r=".22" fill="currentColor"/>
  <circle cx="103" cy="2" r=".22" fill="currentColor"/>
  <circle cx="104" cy="2" r=".22" fill="currentColor"/>
  <circle cx="105" cy="2" r=".22" fill="currentColor"/>
  <circle cx="106" cy="2" r=".22" fill="currentColor"/>
  <circle cx="107" cy="2" r=".22" fill="currentColor"/>
  <circle cx="108" cy="2" r=".22" fill="currentColor"/>
  <circle cx="109" cy="2" r=".22" fill="currentColor"/>
  <circle cx="110" cy="2" r=".22" fill="currentColor"/>
  <circle cx="111" cy="2" r=".22" fill="currentColor"/>
  <circle cx="112" cy="2" r=".22" fill="currentColor"/>
  <circle cx="113" cy="2" r=".22" fill="currentColor"/>
  <circle cx="114" cy="2" r=".22" fill="currentColor"/>
  <circle cx="115" cy="2" r=".22" fill="currentColor"/>
  <circle cx="116" cy="2" r=".22" fill="currentColor"/>
  <circle cx="117" cy="2" r=".22" fill="currentColor"/>
  <circle cx="118" cy="2" r=".22" fill="currentColor"/>
  <circle cx="119" cy="2" r=".22" fill="currentColor"/>
  <circle cx="120" cy="2" r=".22" fill="currentColor"/>
  <circle cx="121" cy="2" r=".22" fill="currentColor"/>
  <circle cx="122" cy="2" r=".22" fill="currentColor"/>
  <circle cx="124" cy="2" r=".22" fill="currentColor"/>
  <circle cx="125" cy="2" r=".22" fill="currentColor"/>
  <circle cy="3" r=".22" fill="currentColor"/>
  <circle cx="5" cy="3" r=".22" fill="currentColor"/>
  <circle cx="6" cy="3" r=".22" fill="currentColor"/>
  <circle cx="7" cy="3" r=".22" fill="currentColor"/>
  <circle cx="8" cy="3" r=".22" fill="currentColor"/>
  <circle cx="9" cy="3" r=".22" fill="currentColor"/>
  <circle cx="10" cy="3" r=".22" fill="currentColor"/>
  <circle cx="11" cy="3" r=".22" fill="currentColor"/>
  <circle cx="12" cy="3" r=".22" fill="currentColor"/>
  <circle cx="13" cy="3" r=".22" fill="currentColor"/>
  <circle cx="14" cy="3" r=".22" fill="currentColor"/>
  <circle cx="15" cy="3" r=".22" fill="currentColor"/>
  <circle cx="16" cy="3" r=".22" fill="currentColor"/>
  <circle cx="17" cy="3" r=".22" fill="currentColor"/>
  <circle cx="18" cy="3" r=".22" fill="currentColor"/>
  <circle cx="19" cy="3" r=".22" fill="currentColor"/>
  <circle cx="20" cy="3" r=".22" fill="currentColor"/>
  <circle cx="21" cy="3" r=".22" fill="currentColor"/>
  <circle cx="22" cy="3" r=".22" fill="currentColor"/>
  <circle cx="25" cy="3" r=".22" fill="currentColor"/>
  <circle cx="26" cy="3" r=".22" fill="currentColor"/>
  <circle cx="29" cy="3" r=".22" fill="currentColor"/>
  <circle cx="30" cy="3" r=".22" fill="currentColor"/>
  <circle cx="31" cy="3" r=".22" fill="currentColor"/>
  <circle cx="33" cy="3" r=".22" fill="currentColor"/>
  <circle cx="34" cy="3" r=".22" fill="currentColor"/>
  <circle cx="36" cy="3" r=".22" fill="currentColor"/>
  <circle cx="38" cy="3" r=".22" fill="currentColor"/>
  <circle cx="39" cy="3" r=".22" fill="currentColor"/>
  <circle cx="45" cy="3" r=".22" fill="currentColor"/>
  <circle cx="46" cy="3" r=".22" fill="currentColor"/>
  <circle cx="47" cy="3" r=".22" fill="currentColor"/>
  <circle cx="48" cy="3" r=".22" fill="currentColor"/>
  <circle cx="49" cy="3" r=".22" fill="currentColor"/>
  <circle cx="50" cy="3" r=".22" fill="currentColor"/>
  <circle cx="51" cy="3" r=".22" fill="currentColor"/>
  <circle cx="69" cy="3" r=".22" fill="currentColor"/>
  <circle cx="70" cy="3" r=".22" fill="currentColor"/>
  <circle cx="71" cy="3" r=".22" fill="currentColor"/>
  <circle cx="72" cy="3" r=".22" fill="currentColor"/>
  <circle cx="73" cy="3" r=".22" fill="currentColor"/>
  <circle cx="74" cy="3" r=".22" fill="currentColor"/>
  <circle cx="75" cy="3" r=".22" fill="currentColor"/>
  <circle cx="76" cy="3" r=".22" fill="currentColor"/>
  <circle cx="77" cy="3" r=".22" fill="currentColor"/>
  <circle cx="79" cy="3" r=".22" fill="currentColor"/>
  <circle cx="81" cy="3" r=".22" fill="currentColor"/>
  <circle cx="82" cy="3" r=".22" fill="currentColor"/>
  <circle cx="83" cy="3" r=".22" fill="currentColor"/>
  <circle cx="84" cy="3" r=".22" fill="currentColor"/>
  <circle cx="85" cy="3" r=".22" fill="currentColor"/>
  <circle cx="86" cy="3" r=".22" fill="currentColor"/>
  <circle cx="87" cy="3" r=".22" fill="currentColor"/>
  <circle cx="88" cy="3" r=".22" fill="currentColor"/>
  <circle cx="90" cy="3" r=".22" fill="currentColor"/>
  <circle cx="91" cy="3" r=".22" fill="currentColor"/>
  <circle cx="92" cy="3" r=".22" fill="currentColor"/>
  <circle cx="93" cy="3" r=".22" fill="currentColor"/>
  <circle cx="94" cy="3" r=".22" fill="currentColor"/>
  <circle cx="95" cy="3" r=".22" fill="currentColor"/>
  <circle cx="96" cy="3" r=".22" fill="currentColor"/>
  <circle cx="97" cy="3" r=".22" fill="currentColor"/>
  <circle cx="98" cy="3" r=".22" fill="currentColor"/>
  <circle cx="99" cy="3" r=".22" fill="currentColor"/>
  <circle cx="100" cy="3" r=".22" fill="currentColor"/>
  <circle cx="101" cy="3" r=".22" fill="currentColor"/>
  <circle cx="102" cy="3" r=".22" fill="currentColor"/>
  <circle cx="103" cy="3" r=".22" fill="currentColor"/>
  <circle cx="104" cy="3" r=".22" fill="currentColor"/>
  <circle cx="105" cy="3" r=".22" fill="currentColor"/>
  <circle cx="106" cy="3" r=".22" fill="currentColor"/>
  <circle cx="107" cy="3" r=".22" fill="currentColor"/>
  <circle cx="108" cy="3" r=".22" fill="currentColor"/>
  <circle cx="109" cy="3" r=".22" fill="currentColor"/>
  <circle cx="110" cy="3" r=".22" fill="currentColor"/>
  <circle cx="111" cy="3" r=".22" fill="currentColor"/>
  <circle cx="112" cy="3" r=".22" fill="currentColor"/>
  <circle cx="113" cy="3" r=".22" fill="currentColor"/>
  <circle cx="114" cy="3" r=".22" fill="currentColor"/>
  <circle cx="115" cy="3" r=".22" fill="currentColor"/>
  <circle cx="116" cy="3" r=".22" fill="currentColor"/>
  <circle cx="117" cy="3" r=".22" fill="currentColor"/>
  <circle cx="118" cy="3" r=".22" fill="currentColor"/>
  <circle cx="119" cy="3" r=".22" fill="currentColor"/>
  <circle cx="120" cy="3" r=".22" fill="currentColor"/>
  <circle cx="121" cy="3" r=".22" fill="currentColor"/>
  <circle cx="122" cy="3" r=".22" fill="currentColor"/>
  <circle cx="123" cy="3" r=".22" fill="currentColor"/>
  <circle cx="124" cy="3" r=".22" fill="currentColor"/>
  <circle cx="125" cy="3" r=".22" fill="currentColor"/>
  <circle cy="4" r=".22" fill="currentColor"/>
  <circle cx="1" cy="4" r=".22" fill="currentColor"/>
  <circle cx="2" cy="4" r=".22" fill="currentColor"/>
  <circle cx="6" cy="4" r=".22" fill="currentColor"/>
  <circle cx="7" cy="4" r=".22" fill="currentColor"/>
  <circle cx="8" cy="4" r=".22" fill="currentColor"/>
  <circle cx="9" cy="4" r=".22" fill="currentColor"/>
  <circle cx="10" cy="4" r=".22" fill="currentColor"/>
  <circle cx="11" cy="4" r=".22" fill="currentColor"/>
  <circle cx="12" cy="4" r=".22" fill="currentColor"/>
  <circle cx="13" cy="4" r=".22" fill="currentColor"/>
  <circle cx="14" cy="4" r=".22" fill="currentColor"/>
  <circle cx="15" cy="4" r=".22" fill="currentColor"/>
  <circle cx="16" cy="4" r=".22" fill="currentColor"/>
  <circle cx="17" cy="4" r=".22" fill="currentColor"/>
  <circle cx="18" cy="4" r=".22" fill="currentColor"/>
  <circle cx="19" cy="4" r=".22" fill="currentColor"/>
  <circle cx="20" cy="4" r=".22" fill="currentColor"/>
  <circle cx="21" cy="4" r=".22" fill="currentColor"/>
  <circle cx="22" cy="4" r=".22" fill="currentColor"/>
  <circle cx="23" cy="4" r=".22" fill="currentColor"/>
  <circle cx="24" cy="4" r=".22" fill="currentColor"/>
  <circle cx="25" cy="4" r=".22" fill="currentColor"/>
  <circle cx="26" cy="4" r=".22" fill="currentColor"/>
  <circle cx="27" cy="4" r=".22" fill="currentColor"/>
  <circle cx="28" cy="4" r=".22" fill="currentColor"/>
  <circle cx="29" cy="4" r=".22" fill="currentColor"/>
  <circle cx="30" cy="4" r=".22" fill="currentColor"/>
  <circle cx="31" cy="4" r=".22" fill="currentColor"/>
  <circle cx="32" cy="4" r=".22" fill="currentColor"/>
  <circle cx="33" cy="4" r=".22" fill="currentColor"/>
  <circle cx="34" cy="4" r=".22" fill="currentColor"/>
  <circle cx="38" cy="4" r=".22" fill="currentColor"/>
  <circle cx="39" cy="4" r=".22" fill="currentColor"/>
  <circle cx="40" cy="4" r=".22" fill="currentColor"/>
  <circle cx="45" cy="4" r=".22" fill="currentColor"/>
  <circle cx="46" cy="4" r=".22" fill="currentColor"/>
  <circle cx="47" cy="4" r=".22" fill="currentColor"/>
  <circle cx="48" cy="4" r=".22" fill="currentColor"/>
  <circle cx="49" cy="4" r=".22" fill="currentColor"/>
  <circle cx="50" cy="4" r=".22" fill="currentColor"/>
  <circle cx="51" cy="4" r=".22" fill="currentColor"/>
  <circle cx="68" cy="4" r=".22" fill="currentColor"/>
  <circle cx="69" cy="4" r=".22" fill="currentColor"/>
  <circle cx="70" cy="4" r=".22" fill="currentColor"/>
  <circle cx="71" cy="4" r=".22" fill="currentColor"/>
  <circle cx="72" cy="4" r=".22" fill="currentColor"/>
  <circle cx="73" cy="4" r=".22" fill="currentColor"/>
  <circle cx="74" cy="4" r=".22" fill="currentColor"/>
  <circle cx="75" cy="4" r=".22" fill="currentColor"/>
  <circle cx="76" cy="4" r=".22" fill="currentColor"/>
  <circle cx="77" cy="4" r=".22" fill="currentColor"/>
  <circle cx="79" cy="4" r=".22" fill="currentColor"/>
  <circle cx="80" cy="4" r=".22" fill="currentColor"/>
  <circle cx="81" cy="4" r=".22" fill="currentColor"/>
  <circle cx="82" cy="4" r=".22" fill="currentColor"/>
  <circle cx="83" cy="4" r=".22" fill="currentColor"/>
  <circle cx="84" cy="4" r=".22" fill="currentColor"/>
  <circle cx="85" cy="4" r=".22" fill="currentColor"/>
  <circle cx="86" cy="4" r=".22" fill="currentColor"/>
  <circle cx="87" cy="4" r=".22" fill="currentColor"/>
  <circle cx="88" cy="4" r=".22" fill="currentColor"/>
  <circle cx="90" cy="4" r=".22" fill="currentColor"/>
  <circle cx="91" cy="4" r=".22" fill="currentColor"/>
  <circle cx="92" cy="4" r=".22" fill="currentColor"/>
  <circle cx="93" cy="4" r=".22" fill="currentColor"/>
  <circle cx="94" cy="4" r=".22" fill="currentColor"/>
  <circle cx="95" cy="4" r=".22" fill="currentColor"/>
  <circle cx="96" cy="4" r=".22" fill="currentColor"/>
  <circle cx="97" cy="4" r=".22" fill="currentColor"/>
  <circle cx="98" cy="4" r=".22" fill="currentColor"/>
  <circle cx="99" cy="4" r=".22" fill="currentColor"/>
  <circle cx="100" cy="4" r=".22" fill="currentColor"/>
  <circle cx="101" cy="4" r=".22" fill="currentColor"/>
  <circle cx="102" cy="4" r=".22" fill="currentColor"/>
  <circle cx="103" cy="4" r=".22" fill="currentColor"/>
  <circle cx="104" cy="4" r=".22" fill="currentColor"/>
  <circle cx="105" cy="4" r=".22" fill="currentColor"/>
  <circle cx="106" cy="4" r=".22" fill="currentColor"/>
  <circle cx="107" cy="4" r=".22" fill="currentColor"/>
  <circle cx="108" cy="4" r=".22" fill="currentColor"/>
  <circle cx="109" cy="4" r=".22" fill="currentColor"/>
  <circle cx="110" cy="4" r=".22" fill="currentColor"/>
  <circle cx="111" cy="4" r=".22" fill="currentColor"/>
  <circle cx="112" cy="4" r=".22" fill="currentColor"/>
  <circle cx="113" cy="4" r=".22" fill="currentColor"/>
  <circle cx="114" cy="4" r=".22" fill="currentColor"/>
  <circle cx="115" cy="4" r=".22" fill="currentColor"/>
  <circle cx="116" cy="4" r=".22" fill="currentColor"/>
  <circle cx="117" cy="4" r=".22" fill="currentColor"/>
  <circle cx="118" cy="4" r=".22" fill="currentColor"/>
  <circle cx="119" cy="4" r=".22" fill="currentColor"/>
  <circle cx="120" cy="4" r=".22" fill="currentColor"/>
  <circle cx="121" cy="4" r=".22" fill="currentColor"/>
  <circle cx="122" cy="4" r=".22" fill="currentColor"/>
  <circle cx="123" cy="4" r=".22" fill="currentColor"/>
  <circle cx="124" cy="4" r=".22" fill="currentColor"/>
  <circle cx="125" cy="4" r=".22" fill="currentColor"/>
  <circle cx="1" cy="5" r=".22" fill="currentColor"/>
  <circle cx="2" cy="5" r=".22" fill="currentColor"/>
  <circle cx="3" cy="5" r=".22" fill="currentColor"/>
  <circle cx="4" cy="5" r=".22" fill="currentColor"/>
  <circle cx="5" cy="5" r=".22" fill="currentColor"/>
  <circle cx="6" cy="5" r=".22" fill="currentColor"/>
  <circle cx="7" cy="5" r=".22" fill="currentColor"/>
  <circle cx="8" cy="5" r=".22" fill="currentColor"/>
  <circle cx="9" cy="5" r=".22" fill="currentColor"/>
  <circle cx="10" cy="5" r=".22" fill="currentColor"/>
  <circle cx="11" cy="5" r=".22" fill="currentColor"/>
  <circle cx="12" cy="5" r=".22" fill="currentColor"/>
  <circle cx="13" cy="5" r=".22" fill="currentColor"/>
  <circle cx="14" cy="5" r=".22" fill="currentColor"/>
  <circle cx="15" cy="5" r=".22" fill="currentColor"/>
  <circle cx="16" cy="5" r=".22" fill="currentColor"/>
  <circle cx="17" cy="5" r=".22" fill="currentColor"/>
  <circle cx="18" cy="5" r=".22" fill="currentColor"/>
  <circle cx="19" cy="5" r=".22" fill="currentColor"/>
  <circle cx="20" cy="5" r=".22" fill="currentColor"/>
  <circle cx="21" cy="5" r=".22" fill="currentColor"/>
  <circle cx="22" cy="5" r=".22" fill="currentColor"/>
  <circle cx="23" cy="5" r=".22" fill="currentColor"/>
  <circle cx="24" cy="5" r=".22" fill="currentColor"/>
  <circle cx="25" cy="5" r=".22" fill="currentColor"/>
  <circle cx="26" cy="5" r=".22" fill="currentColor"/>
  <circle cx="27" cy="5" r=".22" fill="currentColor"/>
  <circle cx="28" cy="5" r=".22" fill="currentColor"/>
  <circle cx="29" cy="5" r=".22" fill="currentColor"/>
  <circle cx="30" cy="5" r=".22" fill="currentColor"/>
  <circle cx="31" cy="5" r=".22" fill="currentColor"/>
  <circle cx="32" cy="5" r=".22" fill="currentColor"/>
  <circle cx="37" cy="5" r=".22" fill="currentColor"/>
  <circle cx="38" cy="5" r=".22" fill="currentColor"/>
  <circle cx="39" cy="5" r=".22" fill="currentColor"/>
  <circle cx="40" cy="5" r=".22" fill="currentColor"/>
  <circle cx="45" cy="5" r=".22" fill="currentColor"/>
  <circle cx="46" cy="5" r=".22" fill="currentColor"/>
  <circle cx="47" cy="5" r=".22" fill="currentColor"/>
  <circle cx="48" cy="5" r=".22" fill="currentColor"/>
  <circle cx="49" cy="5" r=".22" fill="currentColor"/>
  <circle cx="55" cy="5" r=".22" fill="currentColor"/>
  <circle cx="56" cy="5" r=".22" fill="currentColor"/>
  <circle cx="57" cy="5" r=".22" fill="currentColor"/>
  <circle cx="68" cy="5" r=".22" fill="currentColor"/>
  <circle cx="69" cy="5" r=".22" fill="currentColor"/>
  <circle cx="70" cy="5" r=".22" fill="currentColor"/>
  <circle cx="72" cy="5" r=".22" fill="currentColor"/>
  <circle cx="73" cy="5" r=".22" fill="currentColor"/>
  <circle cx="74" cy="5" r=".22" fill="currentColor"/>
  <circle cx="75" cy="5" r=".22" fill="currentColor"/>
  <circle cx="78" cy="5" r=".22" fill="currentColor"/>
  <circle cx="79" cy="5" r=".22" fill="currentColor"/>
  <circle cx="80" cy="5" r=".22" fill="currentColor"/>
  <circle cx="81" cy="5" r=".22" fill="currentColor"/>
  <circle cx="82" cy="5" r=".22" fill="currentColor"/>
  <circle cx="83" cy="5" r=".22" fill="currentColor"/>
  <circle cx="84" cy="5" r=".22" fill="currentColor"/>
  <circle cx="85" cy="5" r=".22" fill="currentColor"/>
  <circle cx="86" cy="5" r=".22" fill="currentColor"/>
  <circle cx="87" cy="5" r=".22" fill="currentColor"/>
  <circle cx="88" cy="5" r=".22" fill="currentColor"/>
  <circle cx="89" cy="5" r=".22" fill="currentColor"/>
  <circle cx="90" cy="5" r=".22" fill="currentColor"/>
  <circle cx="91" cy="5" r=".22" fill="currentColor"/>
  <circle cx="92" cy="5" r=".22" fill="currentColor"/>
  <circle cx="93" cy="5" r=".22" fill="currentColor"/>
  <circle cx="94" cy="5" r=".22" fill="currentColor"/>
  <circle cx="95" cy="5" r=".22" fill="currentColor"/>
  <circle cx="96" cy="5" r=".22" fill="currentColor"/>
  <circle cx="97" cy="5" r=".22" fill="currentColor"/>
  <circle cx="98" cy="5" r=".22" fill="currentColor"/>
  <circle cx="99" cy="5" r=".22" fill="currentColor"/>
  <circle cx="100" cy="5" r=".22" fill="currentColor"/>
  <circle cx="101" cy="5" r=".22" fill="currentColor"/>
  <circle cx="102" cy="5" r=".22" fill="currentColor"/>
  <circle cx="103" cy="5" r=".22" fill="currentColor"/>
  <circle cx="104" cy="5" r=".22" fill="currentColor"/>
  <circle cx="105" cy="5" r=".22" fill="currentColor"/>
  <circle cx="106" cy="5" r=".22" fill="currentColor"/>
  <circle cx="107" cy="5" r=".22" fill="currentColor"/>
  <circle cx="108" cy="5" r=".22" fill="currentColor"/>
  <circle cx="109" cy="5" r=".22" fill="currentColor"/>
  <circle cx="110" cy="5" r=".22" fill="currentColor"/>
  <circle cx="111" cy="5" r=".22" fill="currentColor"/>
  <circle cx="112" cy="5" r=".22" fill="currentColor"/>
  <circle cx="113" cy="5" r=".22" fill="currentColor"/>
  <circle cx="114" cy="5" r=".22" fill="currentColor"/>
  <circle cx="115" cy="5" r=".22" fill="currentColor"/>
  <circle cx="116" cy="5" r=".22" fill="currentColor"/>
  <circle cx="117" cy="5" r=".22" fill="currentColor"/>
  <circle cx="118" cy="5" r=".22" fill="currentColor"/>
  <circle cx="119" cy="5" r=".22" fill="currentColor"/>
  <circle cx="120" cy="5" r=".22" fill="currentColor"/>
  <circle cx="121" cy="5" r=".22" fill="currentColor"/>
  <circle cx="122" cy="5" r=".22" fill="currentColor"/>
  <circle cx="123" cy="5" r=".22" fill="currentColor"/>
  <circle cx="124" cy="5" r=".22" fill="currentColor"/>
  <circle cx="125" cy="5" r=".22" fill="currentColor"/>
  <circle cx="2" cy="6" r=".22" fill="currentColor"/>
  <circle cx="5" cy="6" r=".22" fill="currentColor"/>
  <circle cx="7" cy="6" r=".22" fill="currentColor"/>
  <circle cx="8" cy="6" r=".22" fill="currentColor"/>
  <circle cx="9" cy="6" r=".22" fill="currentColor"/>
  <circle cx="10" cy="6" r=".22" fill="currentColor"/>
  <circle cx="11" cy="6" r=".22" fill="currentColor"/>
  <circle cx="12" cy="6" r=".22" fill="currentColor"/>
  <circle cx="13" cy="6" r=".22" fill="currentColor"/>
  <circle cx="14" cy="6" r=".22" fill="currentColor"/>
  <circle cx="15" cy="6" r=".22" fill="currentColor"/>
  <circle cx="16" cy="6" r=".22" fill="currentColor"/>
  <circle cx="17" cy="6" r=".22" fill="currentColor"/>
  <circle cx="18" cy="6" r=".22" fill="currentColor"/>
  <circle cx="19" cy="6" r=".22" fill="currentColor"/>
  <circle cx="20" cy="6" r=".22" fill="currentColor"/>
  <circle cx="21" cy="6" r=".22" fill="currentColor"/>
  <circle cx="22" cy="6" r=".22" fill="currentColor"/>
  <circle cx="23" cy="6" r=".22" fill="currentColor"/>
  <circle cx="24" cy="6" r=".22" fill="currentColor"/>
  <circle cx="25" cy="6" r=".22" fill="currentColor"/>
  <circle cx="26" cy="6" r=".22" fill="currentColor"/>
  <circle cx="27" cy="6" r=".22" fill="currentColor"/>
  <circle cx="28" cy="6" r=".22" fill="currentColor"/>
  <circle cx="29" cy="6" r=".22" fill="currentColor"/>
  <circle cx="30" cy="6" r=".22" fill="currentColor"/>
  <circle cx="31" cy="6" r=".22" fill="currentColor"/>
  <circle cx="32" cy="6" r=".22" fill="currentColor"/>
  <circle cx="33" cy="6" r=".22" fill="currentColor"/>
  <circle cx="34" cy="6" r=".22" fill="currentColor"/>
  <circle cx="36" cy="6" r=".22" fill="currentColor"/>
  <circle cx="37" cy="6" r=".22" fill="currentColor"/>
  <circle cx="38" cy="6" r=".22" fill="currentColor"/>
  <circle cx="39" cy="6" r=".22" fill="currentColor"/>
  <circle cx="45" cy="6" r=".22" fill="currentColor"/>
  <circle cx="46" cy="6" r=".22" fill="currentColor"/>
  <circle cx="47" cy="6" r=".22" fill="currentColor"/>
  <circle cx="48" cy="6" r=".22" fill="currentColor"/>
  <circle cx="56" cy="6" r=".22" fill="currentColor"/>
  <circle cx="57" cy="6" r=".22" fill="currentColor"/>
  <circle cx="67" cy="6" r=".22" fill="currentColor"/>
  <circle cx="68" cy="6" r=".22" fill="currentColor"/>
  <circle cx="69" cy="6" r=".22" fill="currentColor"/>
  <circle cx="70" cy="6" r=".22" fill="currentColor"/>
  <circle cx="72" cy="6" r=".22" fill="currentColor"/>
  <circle cx="73" cy="6" r=".22" fill="currentColor"/>
  <circle cx="74" cy="6" r=".22" fill="currentColor"/>
  <circle cx="75" cy="6" r=".22" fill="currentColor"/>
  <circle cx="76" cy="6" r=".22" fill="currentColor"/>
  <circle cx="78" cy="6" r=".22" fill="currentColor"/>
  <circle cx="79" cy="6" r=".22" fill="currentColor"/>
  <circle cx="80" cy="6" r=".22" fill="currentColor"/>
  <circle cx="81" cy="6" r=".22" fill="currentColor"/>
  <circle cx="82" cy="6" r=".22" fill="currentColor"/>
  <circle cx="83" cy="6" r=".22" fill="currentColor"/>
  <circle cx="84" cy="6" r=".22" fill="currentColor"/>
  <circle cx="85" cy="6" r=".22" fill="currentColor"/>
  <circle cx="86" cy="6" r=".22" fill="currentColor"/>
  <circle cx="87" cy="6" r=".22" fill="currentColor"/>
  <circle cx="88" cy="6" r=".22" fill="currentColor"/>
  <circle cx="89" cy="6" r=".22" fill="currentColor"/>
  <circle cx="90" cy="6" r=".22" fill="currentColor"/>
  <circle cx="91" cy="6" r=".22" fill="currentColor"/>
  <circle cx="92" cy="6" r=".22" fill="currentColor"/>
  <circle cx="93" cy="6" r=".22" fill="currentColor"/>
  <circle cx="94" cy="6" r=".22" fill="currentColor"/>
  <circle cx="95" cy="6" r=".22" fill="currentColor"/>
  <circle cx="96" cy="6" r=".22" fill="currentColor"/>
  <circle cx="97" cy="6" r=".22" fill="currentColor"/>
  <circle cx="98" cy="6" r=".22" fill="currentColor"/>
  <circle cx="99" cy="6" r=".22" fill="currentColor"/>
  <circle cx="100" cy="6" r=".22" fill="currentColor"/>
  <circle cx="101" cy="6" r=".22" fill="currentColor"/>
  <circle cx="102" cy="6" r=".22" fill="currentColor"/>
  <circle cx="103" cy="6" r=".22" fill="currentColor"/>
  <circle cx="104" cy="6" r=".22" fill="currentColor"/>
  <circle cx="105" cy="6" r=".22" fill="currentColor"/>
  <circle cx="106" cy="6" r=".22" fill="currentColor"/>
  <circle cx="107" cy="6" r=".22" fill="currentColor"/>
  <circle cx="108" cy="6" r=".22" fill="currentColor"/>
  <circle cx="109" cy="6" r=".22" fill="currentColor"/>
  <circle cx="110" cy="6" r=".22" fill="currentColor"/>
  <circle cx="111" cy="6" r=".22" fill="currentColor"/>
  <circle cx="112" cy="6" r=".22" fill="currentColor"/>
  <circle cx="113" cy="6" r=".22" fill="currentColor"/>
  <circle cx="114" cy="6" r=".22" fill="currentColor"/>
  <circle cx="115" cy="6" r=".22" fill="currentColor"/>
  <circle cx="116" cy="6" r=".22" fill="currentColor"/>
  <circle cx="117" cy="6" r=".22" fill="currentColor"/>
  <circle cx="118" cy="6" r=".22" fill="currentColor"/>
  <circle cx="119" cy="6" r=".22" fill="currentColor"/>
  <circle cx="120" cy="6" r=".22" fill="currentColor"/>
  <circle cx="121" cy="6" r=".22" fill="currentColor"/>
  <circle cx="122" cy="6" r=".22" fill="currentColor"/>
  <circle cx="123" cy="6" r=".22" fill="currentColor"/>
  <circle cx="124" cy="6" r=".22" fill="currentColor"/>
  <circle cx="125" cy="6" r=".22" fill="currentColor"/>
  <circle cx="3" cy="7" r=".22" fill="currentColor"/>
  <circle cx="6" cy="7" r=".22" fill="currentColor"/>
  <circle cx="7" cy="7" r=".22" fill="currentColor"/>
  <circle cx="8" cy="7" r=".22" fill="currentColor"/>
  <circle cx="9" cy="7" r=".22" fill="currentColor"/>
  <circle cx="10" cy="7" r=".22" fill="currentColor"/>
  <circle cx="11" cy="7" r=".22" fill="currentColor"/>
  <circle cx="12" cy="7" r=".22" fill="currentColor"/>
  <circle cx="13" cy="7" r=".22" fill="currentColor"/>
  <circle cx="14" cy="7" r=".22" fill="currentColor"/>
  <circle cx="15" cy="7" r=".22" fill="currentColor"/>
  <circle cx="16" cy="7" r=".22" fill="currentColor"/>
  <circle cx="17" cy="7" r=".22" fill="currentColor"/>
  <circle cx="18" cy="7" r=".22" fill="currentColor"/>
  <circle cx="19" cy="7" r=".22" fill="currentColor"/>
  <circle cx="20" cy="7" r=".22" fill="currentColor"/>
  <circle cx="21" cy="7" r=".22" fill="currentColor"/>
  <circle cx="22" cy="7" r=".22" fill="currentColor"/>
  <circle cx="23" cy="7" r=".22" fill="currentColor"/>
  <circle cx="24" cy="7" r=".22" fill="currentColor"/>
  <circle cx="25" cy="7" r=".22" fill="currentColor"/>
  <circle cx="26" cy="7" r=".22" fill="currentColor"/>
  <circle cx="27" cy="7" r=".22" fill="currentColor"/>
  <circle cx="28" cy="7" r=".22" fill="currentColor"/>
  <circle cx="29" cy="7" r=".22" fill="currentColor"/>
  <circle cx="30" cy="7" r=".22" fill="currentColor"/>
  <circle cx="31" cy="7" r=".22" fill="currentColor"/>
  <circle cx="33" cy="7" r=".22" fill="currentColor"/>
  <circle cx="38" cy="7" r=".22" fill="currentColor"/>
  <circle cx="39" cy="7" r=".22" fill="currentColor"/>
  <circle cx="40" cy="7" r=".22" fill="currentColor"/>
  <circle cx="45" cy="7" r=".22" fill="currentColor"/>
  <circle cx="46" cy="7" r=".22" fill="currentColor"/>
  <circle cx="47" cy="7" r=".22" fill="currentColor"/>
  <circle cx="48" cy="7" r=".22" fill="currentColor"/>
  <circle cx="66" cy="7" r=".22" fill="currentColor"/>
  <circle cx="67" cy="7" r=".22" fill="currentColor"/>
  <circle cx="68" cy="7" r=".22" fill="currentColor"/>
  <circle cx="69" cy="7" r=".22" fill="currentColor"/>
  <circle cx="71" cy="7" r=".22" fill="currentColor"/>
  <circle cx="72" cy="7" r=".22" fill="currentColor"/>
  <circle cx="73" cy="7" r=".22" fill="currentColor"/>
  <circle cx="74" cy="7" r=".22" fill="currentColor"/>
  <circle cx="75" cy="7" r=".22" fill="currentColor"/>
  <circle cx="76" cy="7" r=".22" fill="currentColor"/>
  <circle cx="77" cy="7" r=".22" fill="currentColor"/>
  <circle cx="78" cy="7" r=".22" fill="currentColor"/>
  <circle cx="79" cy="7" r=".22" fill="currentColor"/>
  <circle cx="80" cy="7" r=".22" fill="currentColor"/>
  <circle cx="81" cy="7" r=".22" fill="currentColor"/>
  <circle cx="82" cy="7" r=".22" fill="currentColor"/>
  <circle cx="83" cy="7" r=".22" fill="currentColor"/>
  <circle cx="84" cy="7" r=".22" fill="currentColor"/>
  <circle cx="85" cy="7" r=".22" fill="currentColor"/>
  <circle cx="86" cy="7" r=".22" fill="currentColor"/>
  <circle cx="87" cy="7" r=".22" fill="currentColor"/>
  <circle cx="88" cy="7" r=".22" fill="currentColor"/>
  <circle cx="89" cy="7" r=".22" fill="currentColor"/>
  <circle cx="90" cy="7" r=".22" fill="currentColor"/>
  <circle cx="91" cy="7" r=".22" fill="currentColor"/>
  <circle cx="92" cy="7" r=".22" fill="currentColor"/>
  <circle cx="93" cy="7" r=".22" fill="currentColor"/>
  <circle cx="94" cy="7" r=".22" fill="currentColor"/>
  <circle cx="95" cy="7" r=".22" fill="currentColor"/>
  <circle cx="96" cy="7" r=".22" fill="currentColor"/>
  <circle cx="97" cy="7" r=".22" fill="currentColor"/>
  <circle cx="98" cy="7" r=".22" fill="currentColor"/>
  <circle cx="99" cy="7" r=".22" fill="currentColor"/>
  <circle cx="100" cy="7" r=".22" fill="currentColor"/>
  <circle cx="101" cy="7" r=".22" fill="currentColor"/>
  <circle cx="102" cy="7" r=".22" fill="currentColor"/>
  <circle cx="103" cy="7" r=".22" fill="currentColor"/>
  <circle cx="104" cy="7" r=".22" fill="currentColor"/>
  <circle cx="105" cy="7" r=".22" fill="currentColor"/>
  <circle cx="106" cy="7" r=".22" fill="currentColor"/>
  <circle cx="107" cy="7" r=".22" fill="currentColor"/>
  <circle cx="108" cy="7" r=".22" fill="currentColor"/>
  <circle cx="109" cy="7" r=".22" fill="currentColor"/>
  <circle cx="110" cy="7" r=".22" fill="currentColor"/>
  <circle cx="111" cy="7" r=".22" fill="currentColor"/>
  <circle cx="112" cy="7" r=".22" fill="currentColor"/>
  <circle cx="113" cy="7" r=".22" fill="currentColor"/>
  <circle cx="114" cy="7" r=".22" fill="currentColor"/>
  <circle cx="115" cy="7" r=".22" fill="currentColor"/>
  <circle cx="116" cy="7" r=".22" fill="currentColor"/>
  <circle cx="117" cy="7" r=".22" fill="currentColor"/>
  <circle cx="118" cy="7" r=".22" fill="currentColor"/>
  <circle cx="119" cy="7" r=".22" fill="currentColor"/>
  <circle cx="120" cy="7" r=".22" fill="currentColor"/>
  <circle cx="121" cy="7" r=".22" fill="currentColor"/>
  <circle cx="122" cy="7" r=".22" fill="currentColor"/>
  <circle cx="123" cy="7" r=".22" fill="currentColor"/>
  <circle cx="124" cy="7" r=".22" fill="currentColor"/>
  <circle cx="125" cy="7" r=".22" fill="currentColor"/>
  <circle cx="5" cy="8" r=".22" fill="currentColor"/>
  <circle cx="6" cy="8" r=".22" fill="currentColor"/>
  <circle cx="7" cy="8" r=".22" fill="currentColor"/>
  <circle cx="8" cy="8" r=".22" fill="currentColor"/>
  <circle cx="9" cy="8" r=".22" fill="currentColor"/>
  <circle cx="10" cy="8" r=".22" fill="currentColor"/>
  <circle cx="11" cy="8" r=".22" fill="currentColor"/>
  <circle cx="12" cy="8" r=".22" fill="currentColor"/>
  <circle cx="13" cy="8" r=".22" fill="currentColor"/>
  <circle cx="14" cy="8" r=".22" fill="currentColor"/>
  <circle cx="15" cy="8" r=".22" fill="currentColor"/>
  <circle cx="16" cy="8" r=".22" fill="currentColor"/>
  <circle cx="17" cy="8" r=".22" fill="currentColor"/>
  <circle cx="18" cy="8" r=".22" fill="currentColor"/>
  <circle cx="19" cy="8" r=".22" fill="currentColor"/>
  <circle cx="20" cy="8" r=".22" fill="currentColor"/>
  <circle cx="21" cy="8" r=".22" fill="currentColor"/>
  <circle cx="22" cy="8" r=".22" fill="currentColor"/>
  <circle cx="23" cy="8" r=".22" fill="currentColor"/>
  <circle cx="24" cy="8" r=".22" fill="currentColor"/>
  <circle cx="25" cy="8" r=".22" fill="currentColor"/>
  <circle cx="26" cy="8" r=".22" fill="currentColor"/>
  <circle cx="27" cy="8" r=".22" fill="currentColor"/>
  <circle cx="28" cy="8" r=".22" fill="currentColor"/>
  <circle cx="29" cy="8" r=".22" fill="currentColor"/>
  <circle cx="30" cy="8" r=".22" fill="currentColor"/>
  <circle cx="35" cy="8" r=".22" fill="currentColor"/>
  <circle cx="36" cy="8" r=".22" fill="currentColor"/>
  <circle cx="37" cy="8" r=".22" fill="currentColor"/>
  <circle cx="46" cy="8" r=".22" fill="currentColor"/>
  <circle cx="47" cy="8" r=".22" fill="currentColor"/>
  <circle cx="48" cy="8" r=".22" fill="currentColor"/>
  <circle cx="65" cy="8" r=".22" fill="currentColor"/>
  <circle cx="66" cy="8" r=".22" fill="currentColor"/>
  <circle cx="67" cy="8" r=".22" fill="currentColor"/>
  <circle cx="68" cy="8" r=".22" fill="currentColor"/>
  <circle cx="69" cy="8" r=".22" fill="currentColor"/>
  <circle cx="71" cy="8" r=".22" fill="currentColor"/>
  <circle cx="72" cy="8" r=".22" fill="currentColor"/>
  <circle cx="73" cy="8" r=".22" fill="currentColor"/>
  <circle cx="74" cy="8" r=".22" fill="currentColor"/>
  <circle cx="75" cy="8" r=".22" fill="currentColor"/>
  <circle cx="76" cy="8" r=".22" fill="currentColor"/>
  <circle cx="77" cy="8" r=".22" fill="currentColor"/>
  <circle cx="78" cy="8" r=".22" fill="currentColor"/>
  <circle cx="79" cy="8" r=".22" fill="currentColor"/>
  <circle cx="80" cy="8" r=".22" fill="currentColor"/>
  <circle cx="81" cy="8" r=".22" fill="currentColor"/>
  <circle cx="82" cy="8" r=".22" fill="currentColor"/>
  <circle cx="83" cy="8" r=".22" fill="currentColor"/>
  <circle cx="84" cy="8" r=".22" fill="currentColor"/>
  <circle cx="85" cy="8" r=".22" fill="currentColor"/>
  <circle cx="86" cy="8" r=".22" fill="currentColor"/>
  <circle cx="87" cy="8" r=".22" fill="currentColor"/>
  <circle cx="88" cy="8" r=".22" fill="currentColor"/>
  <circle cx="89" cy="8" r=".22" fill="currentColor"/>
  <circle cx="90" cy="8" r=".22" fill="currentColor"/>
  <circle cx="91" cy="8" r=".22" fill="currentColor"/>
  <circle cx="92" cy="8" r=".22" fill="currentColor"/>
  <circle cx="93" cy="8" r=".22" fill="currentColor"/>
  <circle cx="94" cy="8" r=".22" fill="currentColor"/>
  <circle cx="95" cy="8" r=".22" fill="currentColor"/>
  <circle cx="96" cy="8" r=".22" fill="currentColor"/>
  <circle cx="97" cy="8" r=".22" fill="currentColor"/>
  <circle cx="98" cy="8" r=".22" fill="currentColor"/>
  <circle cx="99" cy="8" r=".22" fill="currentColor"/>
  <circle cx="100" cy="8" r=".22" fill="currentColor"/>
  <circle cx="101" cy="8" r=".22" fill="currentColor"/>
  <circle cx="102" cy="8" r=".22" fill="currentColor"/>
  <circle cx="103" cy="8" r=".22" fill="currentColor"/>
  <circle cx="104" cy="8" r=".22" fill="currentColor"/>
  <circle cx="105" cy="8" r=".22" fill="currentColor"/>
  <circle cx="106" cy="8" r=".22" fill="currentColor"/>
  <circle cx="107" cy="8" r=".22" fill="currentColor"/>
  <circle cx="108" cy="8" r=".22" fill="currentColor"/>
  <circle cx="109" cy="8" r=".22" fill="currentColor"/>
  <circle cx="110" cy="8" r=".22" fill="currentColor"/>
  <circle cx="111" cy="8" r=".22" fill="currentColor"/>
  <circle cx="112" cy="8" r=".22" fill="currentColor"/>
  <circle cx="113" cy="8" r=".22" fill="currentColor"/>
  <circle cx="114" cy="8" r=".22" fill="currentColor"/>
  <circle cx="115" cy="8" r=".22" fill="currentColor"/>
  <circle cx="116" cy="8" r=".22" fill="currentColor"/>
  <circle cx="117" cy="8" r=".22" fill="currentColor"/>
  <circle cx="118" cy="8" r=".22" fill="currentColor"/>
  <circle cx="119" cy="8" r=".22" fill="currentColor"/>
  <circle cx="120" cy="8" r=".22" fill="currentColor"/>
  <circle cx="121" cy="8" r=".22" fill="currentColor"/>
  <circle cx="122" cy="8" r=".22" fill="currentColor"/>
  <circle cx="123" cy="8" r=".22" fill="currentColor"/>
  <circle cx="124" cy="8" r=".22" fill="currentColor"/>
  <circle cx="5" cy="9" r=".22" fill="currentColor"/>
  <circle cx="6" cy="9" r=".22" fill="currentColor"/>
  <circle cx="7" cy="9" r=".22" fill="currentColor"/>
  <circle cx="8" cy="9" r=".22" fill="currentColor"/>
  <circle cx="9" cy="9" r=".22" fill="currentColor"/>
  <circle cx="10" cy="9" r=".22" fill="currentColor"/>
  <circle cx="12" cy="9" r=".22" fill="currentColor"/>
  <circle cx="13" cy="9" r=".22" fill="currentColor"/>
  <circle cx="14" cy="9" r=".22" fill="currentColor"/>
  <circle cx="15" cy="9" r=".22" fill="currentColor"/>
  <circle cx="16" cy="9" r=".22" fill="currentColor"/>
  <circle cx="17" cy="9" r=".22" fill="currentColor"/>
  <circle cx="18" cy="9" r=".22" fill="currentColor"/>
  <circle cx="19" cy="9" r=".22" fill="currentColor"/>
  <circle cx="20" cy="9" r=".22" fill="currentColor"/>
  <circle cx="21" cy="9" r=".22" fill="currentColor"/>
  <circle cx="22" cy="9" r=".22" fill="currentColor"/>
  <circle cx="23" cy="9" r=".22" fill="currentColor"/>
  <circle cx="24" cy="9" r=".22" fill="currentColor"/>
  <circle cx="25" cy="9" r=".22" fill="currentColor"/>
  <circle cx="26" cy="9" r=".22" fill="currentColor"/>
  <circle cx="27" cy="9" r=".22" fill="currentColor"/>
  <circle cx="28" cy="9" r=".22" fill="currentColor"/>
  <circle cx="29" cy="9" r=".22" fill="currentColor"/>
  <circle cx="36" cy="9" r=".22" fill="currentColor"/>
  <circle cx="37" cy="9" r=".22" fill="currentColor"/>
  <circle cx="38" cy="9" r=".22" fill="currentColor"/>
  <circle cx="47" cy="9" r=".22" fill="currentColor"/>
  <circle cx="65" cy="9" r=".22" fill="currentColor"/>
  <circle cx="66" cy="9" r=".22" fill="currentColor"/>
  <circle cx="67" cy="9" r=".22" fill="currentColor"/>
  <circle cx="68" cy="9" r=".22" fill="currentColor"/>
  <circle cx="69" cy="9" r=".22" fill="currentColor"/>
  <circle cx="71" cy="9" r=".22" fill="currentColor"/>
  <circle cx="72" cy="9" r=".22" fill="currentColor"/>
  <circle cx="73" cy="9" r=".22" fill="currentColor"/>
  <circle cx="74" cy="9" r=".22" fill="currentColor"/>
  <circle cx="75" cy="9" r=".22" fill="currentColor"/>
  <circle cx="76" cy="9" r=".22" fill="currentColor"/>
  <circle cx="77" cy="9" r=".22" fill="currentColor"/>
  <circle cx="78" cy="9" r=".22" fill="currentColor"/>
  <circle cx="79" cy="9" r=".22" fill="currentColor"/>
  <circle cx="80" cy="9" r=".22" fill="currentColor"/>
  <circle cx="81" cy="9" r=".22" fill="currentColor"/>
  <circle cx="82" cy="9" r=".22" fill="currentColor"/>
  <circle cx="83" cy="9" r=".22" fill="currentColor"/>
  <circle cx="84" cy="9" r=".22" fill="currentColor"/>
  <circle cx="85" cy="9" r=".22" fill="currentColor"/>
  <circle cx="86" cy="9" r=".22" fill="currentColor"/>
  <circle cx="87" cy="9" r=".22" fill="currentColor"/>
  <circle cx="88" cy="9" r=".22" fill="currentColor"/>
  <circle cx="89" cy="9" r=".22" fill="currentColor"/>
  <circle cx="90" cy="9" r=".22" fill="currentColor"/>
  <circle cx="91" cy="9" r=".22" fill="currentColor"/>
  <circle cx="92" cy="9" r=".22" fill="currentColor"/>
  <circle cx="93" cy="9" r=".22" fill="currentColor"/>
  <circle cx="94" cy="9" r=".22" fill="currentColor"/>
  <circle cx="95" cy="9" r=".22" fill="currentColor"/>
  <circle cx="96" cy="9" r=".22" fill="currentColor"/>
  <circle cx="97" cy="9" r=".22" fill="currentColor"/>
  <circle cx="98" cy="9" r=".22" fill="currentColor"/>
  <circle cx="99" cy="9" r=".22" fill="currentColor"/>
  <circle cx="100" cy="9" r=".22" fill="currentColor"/>
  <circle cx="101" cy="9" r=".22" fill="currentColor"/>
  <circle cx="102" cy="9" r=".22" fill="currentColor"/>
  <circle cx="103" cy="9" r=".22" fill="currentColor"/>
  <circle cx="104" cy="9" r=".22" fill="currentColor"/>
  <circle cx="105" cy="9" r=".22" fill="currentColor"/>
  <circle cx="106" cy="9" r=".22" fill="currentColor"/>
  <circle cx="107" cy="9" r=".22" fill="currentColor"/>
  <circle cx="108" cy="9" r=".22" fill="currentColor"/>
  <circle cx="109" cy="9" r=".22" fill="currentColor"/>
  <circle cx="110" cy="9" r=".22" fill="currentColor"/>
  <circle cx="111" cy="9" r=".22" fill="currentColor"/>
  <circle cx="112" cy="9" r=".22" fill="currentColor"/>
  <circle cx="113" cy="9" r=".22" fill="currentColor"/>
  <circle cx="114" cy="9" r=".22" fill="currentColor"/>
  <circle cx="115" cy="9" r=".22" fill="currentColor"/>
  <circle cx="116" cy="9" r=".22" fill="currentColor"/>
  <circle cx="117" cy="9" r=".22" fill="currentColor"/>
  <circle cx="121" cy="9" r=".22" fill="currentColor"/>
  <circle cx="122" cy="9" r=".22" fill="currentColor"/>
  <circle cx="123" cy="9" r=".22" fill="currentColor"/>
  <circle cx="6" cy="10" r=".22" fill="currentColor"/>
  <circle cx="7" cy="10" r=".22" fill="currentColor"/>
  <circle cx="8" cy="10" r=".22" fill="currentColor"/>
  <circle cx="14" cy="10" r=".22" fill="currentColor"/>
  <circle cx="15" cy="10" r=".22" fill="currentColor"/>
  <circle cx="16" cy="10" r=".22" fill="currentColor"/>
  <circle cx="17" cy="10" r=".22" fill="currentColor"/>
  <circle cx="18" cy="10" r=".22" fill="currentColor"/>
  <circle cx="19" cy="10" r=".22" fill="currentColor"/>
  <circle cx="20" cy="10" r=".22" fill="currentColor"/>
  <circle cx="21" cy="10" r=".22" fill="currentColor"/>
  <circle cx="22" cy="10" r=".22" fill="currentColor"/>
  <circle cx="23" cy="10" r=".22" fill="currentColor"/>
  <circle cx="24" cy="10" r=".22" fill="currentColor"/>
  <circle cx="25" cy="10" r=".22" fill="currentColor"/>
  <circle cx="26" cy="10" r=".22" fill="currentColor"/>
  <circle cx="27" cy="10" r=".22" fill="currentColor"/>
  <circle cx="28" cy="10" r=".22" fill="currentColor"/>
  <circle cx="29" cy="10" r=".22" fill="currentColor"/>
  <circle cx="36" cy="10" r=".22" fill="currentColor"/>
  <circle cx="37" cy="10" r=".22" fill="currentColor"/>
  <circle cx="38" cy="10" r=".22" fill="currentColor"/>
  <circle cx="40" cy="10" r=".22" fill="currentColor"/>
  <circle cx="65" cy="10" r=".22" fill="currentColor"/>
  <circle cx="66" cy="10" r=".22" fill="currentColor"/>
  <circle cx="67" cy="10" r=".22" fill="currentColor"/>
  <circle cx="68" cy="10" r=".22" fill="currentColor"/>
  <circle cx="69" cy="10" r=".22" fill="currentColor"/>
  <circle cx="72" cy="10" r=".22" fill="currentColor"/>
  <circle cx="73" cy="10" r=".22" fill="currentColor"/>
  <circle cx="74" cy="10" r=".22" fill="currentColor"/>
  <circle cx="75" cy="10" r=".22" fill="currentColor"/>
  <circle cx="76" cy="10" r=".22" fill="currentColor"/>
  <circle cx="77" cy="10" r=".22" fill="currentColor"/>
  <circle cx="78" cy="10" r=".22" fill="currentColor"/>
  <circle cx="79" cy="10" r=".22" fill="currentColor"/>
  <circle cx="80" cy="10" r=".22" fill="currentColor"/>
  <circle cx="81" cy="10" r=".22" fill="currentColor"/>
  <circle cx="82" cy="10" r=".22" fill="currentColor"/>
  <circle cx="83" cy="10" r=".22" fill="currentColor"/>
  <circle cx="84" cy="10" r=".22" fill="currentColor"/>
  <circle cx="85" cy="10" r=".22" fill="currentColor"/>
  <circle cx="86" cy="10" r=".22" fill="currentColor"/>
  <circle cx="87" cy="10" r=".22" fill="currentColor"/>
  <circle cx="88" cy="10" r=".22" fill="currentColor"/>
  <circle cx="89" cy="10" r=".22" fill="currentColor"/>
  <circle cx="90" cy="10" r=".22" fill="currentColor"/>
  <circle cx="91" cy="10" r=".22" fill="currentColor"/>
  <circle cx="92" cy="10" r=".22" fill="currentColor"/>
  <circle cx="93" cy="10" r=".22" fill="currentColor"/>
  <circle cx="94" cy="10" r=".22" fill="currentColor"/>
  <circle cx="95" cy="10" r=".22" fill="currentColor"/>
  <circle cx="96" cy="10" r=".22" fill="currentColor"/>
  <circle cx="97" cy="10" r=".22" fill="currentColor"/>
  <circle cx="98" cy="10" r=".22" fill="currentColor"/>
  <circle cx="99" cy="10" r=".22" fill="currentColor"/>
  <circle cx="100" cy="10" r=".22" fill="currentColor"/>
  <circle cx="101" cy="10" r=".22" fill="currentColor"/>
  <circle cx="102" cy="10" r=".22" fill="currentColor"/>
  <circle cx="103" cy="10" r=".22" fill="currentColor"/>
  <circle cx="104" cy="10" r=".22" fill="currentColor"/>
  <circle cx="105" cy="10" r=".22" fill="currentColor"/>
  <circle cx="106" cy="10" r=".22" fill="currentColor"/>
  <circle cx="107" cy="10" r=".22" fill="currentColor"/>
  <circle cx="108" cy="10" r=".22" fill="currentColor"/>
  <circle cx="109" cy="10" r=".22" fill="currentColor"/>
  <circle cx="110" cy="10" r=".22" fill="currentColor"/>
  <circle cx="111" cy="10" r=".22" fill="currentColor"/>
  <circle cx="112" cy="10" r=".22" fill="currentColor"/>
  <circle cx="113" cy="10" r=".22" fill="currentColor"/>
  <circle cx="114" cy="10" r=".22" fill="currentColor"/>
  <circle cx="115" cy="10" r=".22" fill="currentColor"/>
  <circle cx="117" cy="10" r=".22" fill="currentColor"/>
  <circle cx="120" cy="10" r=".22" fill="currentColor"/>
  <circle cx="8" cy="11" r=".22" fill="currentColor"/>
  <circle cx="9" cy="11" r=".22" fill="currentColor"/>
  <circle cx="16" cy="11" r=".22" fill="currentColor"/>
  <circle cx="17" cy="11" r=".22" fill="currentColor"/>
  <circle cx="18" cy="11" r=".22" fill="currentColor"/>
  <circle cx="19" cy="11" r=".22" fill="currentColor"/>
  <circle cx="20" cy="11" r=".22" fill="currentColor"/>
  <circle cx="21" cy="11" r=".22" fill="currentColor"/>
  <circle cx="22" cy="11" r=".22" fill="currentColor"/>
  <circle cx="23" cy="11" r=".22" fill="currentColor"/>
  <circle cx="24" cy="11" r=".22" fill="currentColor"/>
  <circle cx="25" cy="11" r=".22" fill="currentColor"/>
  <circle cx="26" cy="11" r=".22" fill="currentColor"/>
  <circle cx="27" cy="11" r=".22" fill="currentColor"/>
  <circle cx="28" cy="11" r=".22" fill="currentColor"/>
  <circle cx="29" cy="11" r=".22" fill="currentColor"/>
  <circle cx="30" cy="11" r=".22" fill="currentColor"/>
  <circle cx="36" cy="11" r=".22" fill="currentColor"/>
  <circle cx="37" cy="11" r=".22" fill="currentColor"/>
  <circle cx="38" cy="11" r=".22" fill="currentColor"/>
  <circle cx="39" cy="11" r=".22" fill="currentColor"/>
  <circle cx="40" cy="11" r=".22" fill="currentColor"/>
  <circle cx="41" cy="11" r=".22" fill="currentColor"/>
  <circle cx="61" cy="11" r=".22" fill="currentColor"/>
  <circle cx="68" cy="11" r=".22" fill="currentColor"/>
  <circle cx="72" cy="11" r=".22" fill="currentColor"/>
  <circle cx="73" cy="11" r=".22" fill="currentColor"/>
  <circle cx="74" cy="11" r=".22" fill="currentColor"/>
  <circle cx="75" cy="11" r=".22" fill="currentColor"/>
  <circle cx="76" cy="11" r=".22" fill="currentColor"/>
  <circle cx="77" cy="11" r=".22" fill="currentColor"/>
  <circle cx="78" cy="11" r=".22" fill="currentColor"/>
  <circle cx="79" cy="11" r=".22" fill="currentColor"/>
  <circle cx="80" cy="11" r=".22" fill="currentColor"/>
  <circle cx="81" cy="11" r=".22" fill="currentColor"/>
  <circle cx="82" cy="11" r=".22" fill="currentColor"/>
  <circle cx="83" cy="11" r=".22" fill="currentColor"/>
  <circle cx="84" cy="11" r=".22" fill="currentColor"/>
  <circle cx="85" cy="11" r=".22" fill="currentColor"/>
  <circle cx="86" cy="11" r=".22" fill="currentColor"/>
  <circle cx="87" cy="11" r=".22" fill="currentColor"/>
  <circle cx="88" cy="11" r=".22" fill="currentColor"/>
  <circle cx="89" cy="11" r=".22" fill="currentColor"/>
  <circle cx="90" cy="11" r=".22" fill="currentColor"/>
  <circle cx="91" cy="11" r=".22" fill="currentColor"/>
  <circle cx="92" cy="11" r=".22" fill="currentColor"/>
  <circle cx="93" cy="11" r=".22" fill="currentColor"/>
  <circle cx="94" cy="11" r=".22" fill="currentColor"/>
  <circle cx="95" cy="11" r=".22" fill="currentColor"/>
  <circle cx="96" cy="11" r=".22" fill="currentColor"/>
  <circle cx="97" cy="11" r=".22" fill="currentColor"/>
  <circle cx="98" cy="11" r=".22" fill="currentColor"/>
  <circle cx="99" cy="11" r=".22" fill="currentColor"/>
  <circle cx="100" cy="11" r=".22" fill="currentColor"/>
  <circle cx="101" cy="11" r=".22" fill="currentColor"/>
  <circle cx="102" cy="11" r=".22" fill="currentColor"/>
  <circle cx="103" cy="11" r=".22" fill="currentColor"/>
  <circle cx="104" cy="11" r=".22" fill="currentColor"/>
  <circle cx="105" cy="11" r=".22" fill="currentColor"/>
  <circle cx="106" cy="11" r=".22" fill="currentColor"/>
  <circle cx="107" cy="11" r=".22" fill="currentColor"/>
  <circle cx="108" cy="11" r=".22" fill="currentColor"/>
  <circle cx="109" cy="11" r=".22" fill="currentColor"/>
  <circle cx="110" cy="11" r=".22" fill="currentColor"/>
  <circle cx="111" cy="11" r=".22" fill="currentColor"/>
  <circle cx="112" cy="11" r=".22" fill="currentColor"/>
  <circle cx="119" cy="11" r=".22" fill="currentColor"/>
  <circle cx="120" cy="11" r=".22" fill="currentColor"/>
  <circle cx="7" cy="12" r=".22" fill="currentColor"/>
  <circle cx="17" cy="12" r=".22" fill="currentColor"/>
  <circle cx="18" cy="12" r=".22" fill="currentColor"/>
  <circle cx="19" cy="12" r=".22" fill="currentColor"/>
  <circle cx="20" cy="12" r=".22" fill="currentColor"/>
  <circle cx="21" cy="12" r=".22" fill="currentColor"/>
  <circle cx="22" cy="12" r=".22" fill="currentColor"/>
  <circle cx="23" cy="12" r=".22" fill="currentColor"/>
  <circle cx="24" cy="12" r=".22" fill="currentColor"/>
  <circle cx="25" cy="12" r=".22" fill="currentColor"/>
  <circle cx="26" cy="12" r=".22" fill="currentColor"/>
  <circle cx="27" cy="12" r=".22" fill="currentColor"/>
  <circle cx="28" cy="12" r=".22" fill="currentColor"/>
  <circle cx="29" cy="12" r=".22" fill="currentColor"/>
  <circle cx="30" cy="12" r=".22" fill="currentColor"/>
  <circle cx="31" cy="12" r=".22" fill="currentColor"/>
  <circle cx="32" cy="12" r=".22" fill="currentColor"/>
  <circle cx="36" cy="12" r=".22" fill="currentColor"/>
  <circle cx="37" cy="12" r=".22" fill="currentColor"/>
  <circle cx="38" cy="12" r=".22" fill="currentColor"/>
  <circle cx="39" cy="12" r=".22" fill="currentColor"/>
  <circle cx="40" cy="12" r=".22" fill="currentColor"/>
  <circle cx="41" cy="12" r=".22" fill="currentColor"/>
  <circle cx="62" cy="12" r=".22" fill="currentColor"/>
  <circle cx="66" cy="12" r=".22" fill="currentColor"/>
  <circle cx="68" cy="12" r=".22" fill="currentColor"/>
  <circle cx="71" cy="12" r=".22" fill="currentColor"/>
  <circle cx="72" cy="12" r=".22" fill="currentColor"/>
  <circle cx="73" cy="12" r=".22" fill="currentColor"/>
  <circle cx="74" cy="12" r=".22" fill="currentColor"/>
  <circle cx="75" cy="12" r=".22" fill="currentColor"/>
  <circle cx="77" cy="12" r=".22" fill="currentColor"/>
  <circle cx="78" cy="12" r=".22" fill="currentColor"/>
  <circle cx="79" cy="12" r=".22" fill="currentColor"/>
  <circle cx="80" cy="12" r=".22" fill="currentColor"/>
  <circle cx="81" cy="12" r=".22" fill="currentColor"/>
  <circle cx="82" cy="12" r=".22" fill="currentColor"/>
  <circle cx="83" cy="12" r=".22" fill="currentColor"/>
  <circle cx="84" cy="12" r=".22" fill="currentColor"/>
  <circle cx="85" cy="12" r=".22" fill="currentColor"/>
  <circle cx="86" cy="12" r=".22" fill="currentColor"/>
  <circle cx="87" cy="12" r=".22" fill="currentColor"/>
  <circle cx="88" cy="12" r=".22" fill="currentColor"/>
  <circle cx="89" cy="12" r=".22" fill="currentColor"/>
  <circle cx="90" cy="12" r=".22" fill="currentColor"/>
  <circle cx="91" cy="12" r=".22" fill="currentColor"/>
  <circle cx="92" cy="12" r=".22" fill="currentColor"/>
  <circle cx="93" cy="12" r=".22" fill="currentColor"/>
  <circle cx="94" cy="12" r=".22" fill="currentColor"/>
  <circle cx="95" cy="12" r=".22" fill="currentColor"/>
  <circle cx="96" cy="12" r=".22" fill="currentColor"/>
  <circle cx="97" cy="12" r=".22" fill="currentColor"/>
  <circle cx="98" cy="12" r=".22" fill="currentColor"/>
  <circle cx="99" cy="12" r=".22" fill="currentColor"/>
  <circle cx="100" cy="12" r=".22" fill="currentColor"/>
  <circle cx="101" cy="12" r=".22" fill="currentColor"/>
  <circle cx="102" cy="12" r=".22" fill="currentColor"/>
  <circle cx="103" cy="12" r=".22" fill="currentColor"/>
  <circle cx="104" cy="12" r=".22" fill="currentColor"/>
  <circle cx="105" cy="12" r=".22" fill="currentColor"/>
  <circle cx="106" cy="12" r=".22" fill="currentColor"/>
  <circle cx="107" cy="12" r=".22" fill="currentColor"/>
  <circle cx="108" cy="12" r=".22" fill="currentColor"/>
  <circle cx="109" cy="12" r=".22" fill="currentColor"/>
  <circle cx="110" cy="12" r=".22" fill="currentColor"/>
  <circle cx="111" cy="12" r=".22" fill="currentColor"/>
  <circle cx="118" cy="12" r=".22" fill="currentColor"/>
  <circle cx="119" cy="12" r=".22" fill="currentColor"/>
  <circle cx="120" cy="12" r=".22" fill="currentColor"/>
  <circle cx="18" cy="13" r=".22" fill="currentColor"/>
  <circle cx="19" cy="13" r=".22" fill="currentColor"/>
  <circle cx="20" cy="13" r=".22" fill="currentColor"/>
  <circle cx="21" cy="13" r=".22" fill="currentColor"/>
  <circle cx="22" cy="13" r=".22" fill="currentColor"/>
  <circle cx="23" cy="13" r=".22" fill="currentColor"/>
  <circle cx="24" cy="13" r=".22" fill="currentColor"/>
  <circle cx="25" cy="13" r=".22" fill="currentColor"/>
  <circle cx="26" cy="13" r=".22" fill="currentColor"/>
  <circle cx="27" cy="13" r=".22" fill="currentColor"/>
  <circle cx="28" cy="13" r=".22" fill="currentColor"/>
  <circle cx="29" cy="13" r=".22" fill="currentColor"/>
  <circle cx="30" cy="13" r=".22" fill="currentColor"/>
  <circle cx="31" cy="13" r=".22" fill="currentColor"/>
  <circle cx="32" cy="13" r=".22" fill="currentColor"/>
  <circle cx="33" cy="13" r=".22" fill="currentColor"/>
  <circle cx="34" cy="13" r=".22" fill="currentColor"/>
  <circle cx="35" cy="13" r=".22" fill="currentColor"/>
  <circle cx="36" cy="13" r=".22" fill="currentColor"/>
  <circle cx="37" cy="13" r=".22" fill="currentColor"/>
  <circle cx="38" cy="13" r=".22" fill="currentColor"/>
  <circle cx="39" cy="13" r=".22" fill="currentColor"/>
  <circle cx="40" cy="13" r=".22" fill="currentColor"/>
  <circle cx="41" cy="13" r=".22" fill="currentColor"/>
  <circle cx="42" cy="13" r=".22" fill="currentColor"/>
  <circle cx="62" cy="13" r=".22" fill="currentColor"/>
  <circle cx="69" cy="13" r=".22" fill="currentColor"/>
  <circle cx="70" cy="13" r=".22" fill="currentColor"/>
  <circle cx="71" cy="13" r=".22" fill="currentColor"/>
  <circle cx="72" cy="13" r=".22" fill="currentColor"/>
  <circle cx="73" cy="13" r=".22" fill="currentColor"/>
  <circle cx="74" cy="13" r=".22" fill="currentColor"/>
  <circle cx="75" cy="13" r=".22" fill="currentColor"/>
  <circle cx="76" cy="13" r=".22" fill="currentColor"/>
  <circle cx="77" cy="13" r=".22" fill="currentColor"/>
  <circle cx="78" cy="13" r=".22" fill="currentColor"/>
  <circle cx="79" cy="13" r=".22" fill="currentColor"/>
  <circle cx="80" cy="13" r=".22" fill="currentColor"/>
  <circle cx="81" cy="13" r=".22" fill="currentColor"/>
  <circle cx="82" cy="13" r=".22" fill="currentColor"/>
  <circle cx="83" cy="13" r=".22" fill="currentColor"/>
  <circle cx="84" cy="13" r=".22" fill="currentColor"/>
  <circle cx="85" cy="13" r=".22" fill="currentColor"/>
  <circle cx="86" cy="13" r=".22" fill="currentColor"/>
  <circle cx="87" cy="13" r=".22" fill="currentColor"/>
  <circle cx="88" cy="13" r=".22" fill="currentColor"/>
  <circle cx="89" cy="13" r=".22" fill="currentColor"/>
  <circle cx="90" cy="13" r=".22" fill="currentColor"/>
  <circle cx="91" cy="13" r=".22" fill="currentColor"/>
  <circle cx="92" cy="13" r=".22" fill="currentColor"/>
  <circle cx="93" cy="13" r=".22" fill="currentColor"/>
  <circle cx="94" cy="13" r=".22" fill="currentColor"/>
  <circle cx="95" cy="13" r=".22" fill="currentColor"/>
  <circle cx="96" cy="13" r=".22" fill="currentColor"/>
  <circle cx="97" cy="13" r=".22" fill="currentColor"/>
  <circle cx="98" cy="13" r=".22" fill="currentColor"/>
  <circle cx="99" cy="13" r=".22" fill="currentColor"/>
  <circle cx="100" cy="13" r=".22" fill="currentColor"/>
  <circle cx="101" cy="13" r=".22" fill="currentColor"/>
  <circle cx="102" cy="13" r=".22" fill="currentColor"/>
  <circle cx="103" cy="13" r=".22" fill="currentColor"/>
  <circle cx="104" cy="13" r=".22" fill="currentColor"/>
  <circle cx="105" cy="13" r=".22" fill="currentColor"/>
  <circle cx="106" cy="13" r=".22" fill="currentColor"/>
  <circle cx="107" cy="13" r=".22" fill="currentColor"/>
  <circle cx="108" cy="13" r=".22" fill="currentColor"/>
  <circle cx="109" cy="13" r=".22" fill="currentColor"/>
  <circle cx="110" cy="13" r=".22" fill="currentColor"/>
  <circle cx="118" cy="13" r=".22" fill="currentColor"/>
  <circle cx="119" cy="13" r=".22" fill="currentColor"/>
  <circle cx="18" cy="14" r=".22" fill="currentColor"/>
  <circle cx="19" cy="14" r=".22" fill="currentColor"/>
  <circle cx="20" cy="14" r=".22" fill="currentColor"/>
  <circle cx="21" cy="14" r=".22" fill="currentColor"/>
  <circle cx="22" cy="14" r=".22" fill="currentColor"/>
  <circle cx="23" cy="14" r=".22" fill="currentColor"/>
  <circle cx="24" cy="14" r=".22" fill="currentColor"/>
  <circle cx="25" cy="14" r=".22" fill="currentColor"/>
  <circle cx="26" cy="14" r=".22" fill="currentColor"/>
  <circle cx="27" cy="14" r=".22" fill="currentColor"/>
  <circle cx="28" cy="14" r=".22" fill="currentColor"/>
  <circle cx="29" cy="14" r=".22" fill="currentColor"/>
  <circle cx="30" cy="14" r=".22" fill="currentColor"/>
  <circle cx="31" cy="14" r=".22" fill="currentColor"/>
  <circle cx="32" cy="14" r=".22" fill="currentColor"/>
  <circle cx="33" cy="14" r=".22" fill="currentColor"/>
  <circle cx="34" cy="14" r=".22" fill="currentColor"/>
  <circle cx="36" cy="14" r=".22" fill="currentColor"/>
  <circle cx="37" cy="14" r=".22" fill="currentColor"/>
  <circle cx="38" cy="14" r=".22" fill="currentColor"/>
  <circle cx="39" cy="14" r=".22" fill="currentColor"/>
  <circle cx="40" cy="14" r=".22" fill="currentColor"/>
  <circle cx="41" cy="14" r=".22" fill="currentColor"/>
  <circle cx="42" cy="14" r=".22" fill="currentColor"/>
  <circle cx="43" cy="14" r=".22" fill="currentColor"/>
  <circle cx="60" cy="14" r=".22" fill="currentColor"/>
  <circle cx="62" cy="14" r=".22" fill="currentColor"/>
  <circle cx="63" cy="14" r=".22" fill="currentColor"/>
  <circle cx="65" cy="14" r=".22" fill="currentColor"/>
  <circle cx="66" cy="14" r=".22" fill="currentColor"/>
  <circle cx="67" cy="14" r=".22" fill="currentColor"/>
  <circle cx="69" cy="14" r=".22" fill="currentColor"/>
  <circle cx="70" cy="14" r=".22" fill="currentColor"/>
  <circle cx="71" cy="14" r=".22" fill="currentColor"/>
  <circle cx="72" cy="14" r=".22" fill="currentColor"/>
  <circle cx="73" cy="14" r=".22" fill="currentColor"/>
  <circle cx="74" cy="14" r=".22" fill="currentColor"/>
  <circle cx="75" cy="14" r=".22" fill="currentColor"/>
  <circle cx="76" cy="14" r=".22" fill="currentColor"/>
  <circle cx="77" cy="14" r=".22" fill="currentColor"/>
  <circle cx="78" cy="14" r=".22" fill="currentColor"/>
  <circle cx="79" cy="14" r=".22" fill="currentColor"/>
  <circle cx="80" cy="14" r=".22" fill="currentColor"/>
  <circle cx="81" cy="14" r=".22" fill="currentColor"/>
  <circle cx="82" cy="14" r=".22" fill="currentColor"/>
  <circle cx="83" cy="14" r=".22" fill="currentColor"/>
  <circle cx="84" cy="14" r=".22" fill="currentColor"/>
  <circle cx="85" cy="14" r=".22" fill="currentColor"/>
  <circle cx="86" cy="14" r=".22" fill="currentColor"/>
  <circle cx="87" cy="14" r=".22" fill="currentColor"/>
  <circle cx="88" cy="14" r=".22" fill="currentColor"/>
  <circle cx="89" cy="14" r=".22" fill="currentColor"/>
  <circle cx="90" cy="14" r=".22" fill="currentColor"/>
  <circle cx="91" cy="14" r=".22" fill="currentColor"/>
  <circle cx="92" cy="14" r=".22" fill="currentColor"/>
  <circle cx="93" cy="14" r=".22" fill="currentColor"/>
  <circle cx="94" cy="14" r=".22" fill="currentColor"/>
  <circle cx="95" cy="14" r=".22" fill="currentColor"/>
  <circle cx="96" cy="14" r=".22" fill="currentColor"/>
  <circle cx="97" cy="14" r=".22" fill="currentColor"/>
  <circle cx="98" cy="14" r=".22" fill="currentColor"/>
  <circle cx="99" cy="14" r=".22" fill="currentColor"/>
  <circle cx="100" cy="14" r=".22" fill="currentColor"/>
  <circle cx="101" cy="14" r=".22" fill="currentColor"/>
  <circle cx="102" cy="14" r=".22" fill="currentColor"/>
  <circle cx="103" cy="14" r=".22" fill="currentColor"/>
  <circle cx="104" cy="14" r=".22" fill="currentColor"/>
  <circle cx="105" cy="14" r=".22" fill="currentColor"/>
  <circle cx="106" cy="14" r=".22" fill="currentColor"/>
  <circle cx="107" cy="14" r=".22" fill="currentColor"/>
  <circle cx="108" cy="14" r=".22" fill="currentColor"/>
  <circle cx="109" cy="14" r=".22" fill="currentColor"/>
  <circle cx="110" cy="14" r=".22" fill="currentColor"/>
  <circle cx="111" cy="14" r=".22" fill="currentColor"/>
  <circle cx="112" cy="14" r=".22" fill="currentColor"/>
  <circle cx="113" cy="14" r=".22" fill="currentColor"/>
  <circle cx="118" cy="14" r=".22" fill="currentColor"/>
  <circle cx="19" cy="15" r=".22" fill="currentColor"/>
  <circle cx="20" cy="15" r=".22" fill="currentColor"/>
  <circle cx="21" cy="15" r=".22" fill="currentColor"/>
  <circle cx="22" cy="15" r=".22" fill="currentColor"/>
  <circle cx="23" cy="15" r=".22" fill="currentColor"/>
  <circle cx="24" cy="15" r=".22" fill="currentColor"/>
  <circle cx="25" cy="15" r=".22" fill="currentColor"/>
  <circle cx="26" cy="15" r=".22" fill="currentColor"/>
  <circle cx="27" cy="15" r=".22" fill="currentColor"/>
  <circle cx="28" cy="15" r=".22" fill="currentColor"/>
  <circle cx="29" cy="15" r=".22" fill="currentColor"/>
  <circle cx="30" cy="15" r=".22" fill="currentColor"/>
  <circle cx="31" cy="15" r=".22" fill="currentColor"/>
  <circle cx="32" cy="15" r=".22" fill="currentColor"/>
  <circle cx="33" cy="15" r=".22" fill="currentColor"/>
  <circle cx="34" cy="15" r=".22" fill="currentColor"/>
  <circle cx="35" cy="15" r=".22" fill="currentColor"/>
  <circle cx="36" cy="15" r=".22" fill="currentColor"/>
  <circle cx="37" cy="15" r=".22" fill="currentColor"/>
  <circle cx="38" cy="15" r=".22" fill="currentColor"/>
  <circle cx="39" cy="15" r=".22" fill="currentColor"/>
  <circle cx="40" cy="15" r=".22" fill="currentColor"/>
  <circle cx="41" cy="15" r=".22" fill="currentColor"/>
  <circle cx="42" cy="15" r=".22" fill="currentColor"/>
  <circle cx="62" cy="15" r=".22" fill="currentColor"/>
  <circle cx="63" cy="15" r=".22" fill="currentColor"/>
  <circle cx="65" cy="15" r=".22" fill="currentColor"/>
  <circle cx="66" cy="15" r=".22" fill="currentColor"/>
  <circle cx="67" cy="15" r=".22" fill="currentColor"/>
  <circle cx="68" cy="15" r=".22" fill="currentColor"/>
  <circle cx="69" cy="15" r=".22" fill="currentColor"/>
  <circle cx="70" cy="15" r=".22" fill="currentColor"/>
  <circle cx="71" cy="15" r=".22" fill="currentColor"/>
  <circle cx="72" cy="15" r=".22" fill="currentColor"/>
  <circle cx="73" cy="15" r=".22" fill="currentColor"/>
  <circle cx="74" cy="15" r=".22" fill="currentColor"/>
  <circle cx="75" cy="15" r=".22" fill="currentColor"/>
  <circle cx="76" cy="15" r=".22" fill="currentColor"/>
  <circle cx="77" cy="15" r=".22" fill="currentColor"/>
  <circle cx="78" cy="15" r=".22" fill="currentColor"/>
  <circle cx="79" cy="15" r=".22" fill="currentColor"/>
  <circle cx="80" cy="15" r=".22" fill="currentColor"/>
  <circle cx="81" cy="15" r=".22" fill="currentColor"/>
  <circle cx="82" cy="15" r=".22" fill="currentColor"/>
  <circle cx="83" cy="15" r=".22" fill="currentColor"/>
  <circle cx="84" cy="15" r=".22" fill="currentColor"/>
  <circle cx="85" cy="15" r=".22" fill="currentColor"/>
  <circle cx="86" cy="15" r=".22" fill="currentColor"/>
  <circle cx="87" cy="15" r=".22" fill="currentColor"/>
  <circle cx="88" cy="15" r=".22" fill="currentColor"/>
  <circle cx="89" cy="15" r=".22" fill="currentColor"/>
  <circle cx="90" cy="15" r=".22" fill="currentColor"/>
  <circle cx="91" cy="15" r=".22" fill="currentColor"/>
  <circle cx="92" cy="15" r=".22" fill="currentColor"/>
  <circle cx="93" cy="15" r=".22" fill="currentColor"/>
  <circle cx="94" cy="15" r=".22" fill="currentColor"/>
  <circle cx="95" cy="15" r=".22" fill="currentColor"/>
  <circle cx="96" cy="15" r=".22" fill="currentColor"/>
  <circle cx="97" cy="15" r=".22" fill="currentColor"/>
  <circle cx="98" cy="15" r=".22" fill="currentColor"/>
  <circle cx="99" cy="15" r=".22" fill="currentColor"/>
  <circle cx="100" cy="15" r=".22" fill="currentColor"/>
  <circle cx="101" cy="15" r=".22" fill="currentColor"/>
  <circle cx="102" cy="15" r=".22" fill="currentColor"/>
  <circle cx="103" cy="15" r=".22" fill="currentColor"/>
  <circle cx="104" cy="15" r=".22" fill="currentColor"/>
  <circle cx="105" cy="15" r=".22" fill="currentColor"/>
  <circle cx="106" cy="15" r=".22" fill="currentColor"/>
  <circle cx="107" cy="15" r=".22" fill="currentColor"/>
  <circle cx="108" cy="15" r=".22" fill="currentColor"/>
  <circle cx="109" cy="15" r=".22" fill="currentColor"/>
  <circle cx="110" cy="15" r=".22" fill="currentColor"/>
  <circle cx="111" cy="15" r=".22" fill="currentColor"/>
  <circle cx="112" cy="15" r=".22" fill="currentColor"/>
  <circle cx="113" cy="15" r=".22" fill="currentColor"/>
  <circle cx="19" cy="16" r=".22" fill="currentColor"/>
  <circle cx="20" cy="16" r=".22" fill="currentColor"/>
  <circle cx="21" cy="16" r=".22" fill="currentColor"/>
  <circle cx="22" cy="16" r=".22" fill="currentColor"/>
  <circle cx="23" cy="16" r=".22" fill="currentColor"/>
  <circle cx="24" cy="16" r=".22" fill="currentColor"/>
  <circle cx="25" cy="16" r=".22" fill="currentColor"/>
  <circle cx="26" cy="16" r=".22" fill="currentColor"/>
  <circle cx="27" cy="16" r=".22" fill="currentColor"/>
  <circle cx="28" cy="16" r=".22" fill="currentColor"/>
  <circle cx="29" cy="16" r=".22" fill="currentColor"/>
  <circle cx="30" cy="16" r=".22" fill="currentColor"/>
  <circle cx="31" cy="16" r=".22" fill="currentColor"/>
  <circle cx="32" cy="16" r=".22" fill="currentColor"/>
  <circle cx="33" cy="16" r=".22" fill="currentColor"/>
  <circle cx="34" cy="16" r=".22" fill="currentColor"/>
  <circle cx="35" cy="16" r=".22" fill="currentColor"/>
  <circle cx="36" cy="16" r=".22" fill="currentColor"/>
  <circle cx="37" cy="16" r=".22" fill="currentColor"/>
  <circle cx="38" cy="16" r=".22" fill="currentColor"/>
  <circle cx="39" cy="16" r=".22" fill="currentColor"/>
  <circle cx="41" cy="16" r=".22" fill="currentColor"/>
  <circle cx="43" cy="16" r=".22" fill="currentColor"/>
  <circle cx="63" cy="16" r=".22" fill="currentColor"/>
  <circle cx="65" cy="16" r=".22" fill="currentColor"/>
  <circle cx="66" cy="16" r=".22" fill="currentColor"/>
  <circle cx="67" cy="16" r=".22" fill="currentColor"/>
  <circle cx="68" cy="16" r=".22" fill="currentColor"/>
  <circle cx="69" cy="16" r=".22" fill="currentColor"/>
  <circle cx="70" cy="16" r=".22" fill="currentColor"/>
  <circle cx="71" cy="16" r=".22" fill="currentColor"/>
  <circle cx="72" cy="16" r=".22" fill="currentColor"/>
  <circle cx="73" cy="16" r=".22" fill="currentColor"/>
  <circle cx="74" cy="16" r=".22" fill="currentColor"/>
  <circle cx="75" cy="16" r=".22" fill="currentColor"/>
  <circle cx="76" cy="16" r=".22" fill="currentColor"/>
  <circle cx="77" cy="16" r=".22" fill="currentColor"/>
  <circle cx="78" cy="16" r=".22" fill="currentColor"/>
  <circle cx="79" cy="16" r=".22" fill="currentColor"/>
  <circle cx="80" cy="16" r=".22" fill="currentColor"/>
  <circle cx="81" cy="16" r=".22" fill="currentColor"/>
  <circle cx="82" cy="16" r=".22" fill="currentColor"/>
  <circle cx="83" cy="16" r=".22" fill="currentColor"/>
  <circle cx="84" cy="16" r=".22" fill="currentColor"/>
  <circle cx="85" cy="16" r=".22" fill="currentColor"/>
  <circle cx="86" cy="16" r=".22" fill="currentColor"/>
  <circle cx="87" cy="16" r=".22" fill="currentColor"/>
  <circle cx="88" cy="16" r=".22" fill="currentColor"/>
  <circle cx="89" cy="16" r=".22" fill="currentColor"/>
  <circle cx="90" cy="16" r=".22" fill="currentColor"/>
  <circle cx="91" cy="16" r=".22" fill="currentColor"/>
  <circle cx="92" cy="16" r=".22" fill="currentColor"/>
  <circle cx="93" cy="16" r=".22" fill="currentColor"/>
  <circle cx="94" cy="16" r=".22" fill="currentColor"/>
  <circle cx="95" cy="16" r=".22" fill="currentColor"/>
  <circle cx="96" cy="16" r=".22" fill="currentColor"/>
  <circle cx="97" cy="16" r=".22" fill="currentColor"/>
  <circle cx="98" cy="16" r=".22" fill="currentColor"/>
  <circle cx="99" cy="16" r=".22" fill="currentColor"/>
  <circle cx="100" cy="16" r=".22" fill="currentColor"/>
  <circle cx="101" cy="16" r=".22" fill="currentColor"/>
  <circle cx="102" cy="16" r=".22" fill="currentColor"/>
  <circle cx="103" cy="16" r=".22" fill="currentColor"/>
  <circle cx="104" cy="16" r=".22" fill="currentColor"/>
  <circle cx="105" cy="16" r=".22" fill="currentColor"/>
  <circle cx="106" cy="16" r=".22" fill="currentColor"/>
  <circle cx="107" cy="16" r=".22" fill="currentColor"/>
  <circle cx="108" cy="16" r=".22" fill="currentColor"/>
  <circle cx="109" cy="16" r=".22" fill="currentColor"/>
  <circle cx="110" cy="16" r=".22" fill="currentColor"/>
  <circle cx="111" cy="16" r=".22" fill="currentColor"/>
  <circle cx="112" cy="16" r=".22" fill="currentColor"/>
  <circle cx="20" cy="17" r=".22" fill="currentColor"/>
  <circle cx="21" cy="17" r=".22" fill="currentColor"/>
  <circle cx="22" cy="17" r=".22" fill="currentColor"/>
  <circle cx="23" cy="17" r=".22" fill="currentColor"/>
  <circle cx="24" cy="17" r=".22" fill="currentColor"/>
  <circle cx="25" cy="17" r=".22" fill="currentColor"/>
  <circle cx="26" cy="17" r=".22" fill="currentColor"/>
  <circle cx="27" cy="17" r=".22" fill="currentColor"/>
  <circle cx="28" cy="17" r=".22" fill="currentColor"/>
  <circle cx="29" cy="17" r=".22" fill="currentColor"/>
  <circle cx="30" cy="17" r=".22" fill="currentColor"/>
  <circle cx="31" cy="17" r=".22" fill="currentColor"/>
  <circle cx="32" cy="17" r=".22" fill="currentColor"/>
  <circle cx="33" cy="17" r=".22" fill="currentColor"/>
  <circle cx="34" cy="17" r=".22" fill="currentColor"/>
  <circle cx="35" cy="17" r=".22" fill="currentColor"/>
  <circle cx="36" cy="17" r=".22" fill="currentColor"/>
  <circle cx="37" cy="17" r=".22" fill="currentColor"/>
  <circle cx="38" cy="17" r=".22" fill="currentColor"/>
  <circle cx="39" cy="17" r=".22" fill="currentColor"/>
  <circle cx="40" cy="17" r=".22" fill="currentColor"/>
  <circle cx="44" cy="17" r=".22" fill="currentColor"/>
  <circle cx="62" cy="17" r=".22" fill="currentColor"/>
  <circle cx="63" cy="17" r=".22" fill="currentColor"/>
  <circle cx="64" cy="17" r=".22" fill="currentColor"/>
  <circle cx="65" cy="17" r=".22" fill="currentColor"/>
  <circle cx="66" cy="17" r=".22" fill="currentColor"/>
  <circle cx="67" cy="17" r=".22" fill="currentColor"/>
  <circle cx="68" cy="17" r=".22" fill="currentColor"/>
  <circle cx="69" cy="17" r=".22" fill="currentColor"/>
  <circle cx="70" cy="17" r=".22" fill="currentColor"/>
  <circle cx="71" cy="17" r=".22" fill="currentColor"/>
  <circle cx="72" cy="17" r=".22" fill="currentColor"/>
  <circle cx="73" cy="17" r=".22" fill="currentColor"/>
  <circle cx="74" cy="17" r=".22" fill="currentColor"/>
  <circle cx="75" cy="17" r=".22" fill="currentColor"/>
  <circle cx="76" cy="17" r=".22" fill="currentColor"/>
  <circle cx="77" cy="17" r=".22" fill="currentColor"/>
  <circle cx="78" cy="17" r=".22" fill="currentColor"/>
  <circle cx="79" cy="17" r=".22" fill="currentColor"/>
  <circle cx="80" cy="17" r=".22" fill="currentColor"/>
  <circle cx="81" cy="17" r=".22" fill="currentColor"/>
  <circle cx="82" cy="17" r=".22" fill="currentColor"/>
  <circle cx="83" cy="17" r=".22" fill="currentColor"/>
  <circle cx="84" cy="17" r=".22" fill="currentColor"/>
  <circle cx="85" cy="17" r=".22" fill="currentColor"/>
  <circle cx="86" cy="17" r=".22" fill="currentColor"/>
  <circle cx="87" cy="17" r=".22" fill="currentColor"/>
  <circle cx="88" cy="17" r=".22" fill="currentColor"/>
  <circle cx="89" cy="17" r=".22" fill="currentColor"/>
  <circle cx="90" cy="17" r=".22" fill="currentColor"/>
  <circle cx="91" cy="17" r=".22" fill="currentColor"/>
  <circle cx="92" cy="17" r=".22" fill="currentColor"/>
  <circle cx="93" cy="17" r=".22" fill="currentColor"/>
  <circle cx="94" cy="17" r=".22" fill="currentColor"/>
  <circle cx="95" cy="17" r=".22" fill="currentColor"/>
  <circle cx="96" cy="17" r=".22" fill="currentColor"/>
  <circle cx="97" cy="17" r=".22" fill="currentColor"/>
  <circle cx="98" cy="17" r=".22" fill="currentColor"/>
  <circle cx="99" cy="17" r=".22" fill="currentColor"/>
  <circle cx="100" cy="17" r=".22" fill="currentColor"/>
  <circle cx="101" cy="17" r=".22" fill="currentColor"/>
  <circle cx="102" cy="17" r=".22" fill="currentColor"/>
  <circle cx="103" cy="17" r=".22" fill="currentColor"/>
  <circle cx="104" cy="17" r=".22" fill="currentColor"/>
  <circle cx="105" cy="17" r=".22" fill="currentColor"/>
  <circle cx="106" cy="17" r=".22" fill="currentColor"/>
  <circle cx="107" cy="17" r=".22" fill="currentColor"/>
  <circle cx="108" cy="17" r=".22" fill="currentColor"/>
  <circle cx="109" cy="17" r=".22" fill="currentColor"/>
  <circle cx="110" cy="17" r=".22" fill="currentColor"/>
  <circle cx="111" cy="17" r=".22" fill="currentColor"/>
  <circle cx="113" cy="17" r=".22" fill="currentColor"/>
  <circle cx="20" cy="18" r=".22" fill="currentColor"/>
  <circle cx="21" cy="18" r=".22" fill="currentColor"/>
  <circle cx="22" cy="18" r=".22" fill="currentColor"/>
  <circle cx="23" cy="18" r=".22" fill="currentColor"/>
  <circle cx="24" cy="18" r=".22" fill="currentColor"/>
  <circle cx="25" cy="18" r=".22" fill="currentColor"/>
  <circle cx="26" cy="18" r=".22" fill="currentColor"/>
  <circle cx="27" cy="18" r=".22" fill="currentColor"/>
  <circle cx="28" cy="18" r=".22" fill="currentColor"/>
  <circle cx="29" cy="18" r=".22" fill="currentColor"/>
  <circle cx="30" cy="18" r=".22" fill="currentColor"/>
  <circle cx="31" cy="18" r=".22" fill="currentColor"/>
  <circle cx="32" cy="18" r=".22" fill="currentColor"/>
  <circle cx="33" cy="18" r=".22" fill="currentColor"/>
  <circle cx="34" cy="18" r=".22" fill="currentColor"/>
  <circle cx="35" cy="18" r=".22" fill="currentColor"/>
  <circle cx="36" cy="18" r=".22" fill="currentColor"/>
  <circle cx="37" cy="18" r=".22" fill="currentColor"/>
  <circle cx="38" cy="18" r=".22" fill="currentColor"/>
  <circle cx="39" cy="18" r=".22" fill="currentColor"/>
  <circle cx="40" cy="18" r=".22" fill="currentColor"/>
  <circle cx="41" cy="18" r=".22" fill="currentColor"/>
  <circle cx="63" cy="18" r=".22" fill="currentColor"/>
  <circle cx="64" cy="18" r=".22" fill="currentColor"/>
  <circle cx="65" cy="18" r=".22" fill="currentColor"/>
  <circle cx="66" cy="18" r=".22" fill="currentColor"/>
  <circle cx="67" cy="18" r=".22" fill="currentColor"/>
  <circle cx="68" cy="18" r=".22" fill="currentColor"/>
  <circle cx="69" cy="18" r=".22" fill="currentColor"/>
  <circle cx="70" cy="18" r=".22" fill="currentColor"/>
  <circle cx="71" cy="18" r=".22" fill="currentColor"/>
  <circle cx="72" cy="18" r=".22" fill="currentColor"/>
  <circle cx="73" cy="18" r=".22" fill="currentColor"/>
  <circle cx="75" cy="18" r=".22" fill="currentColor"/>
  <circle cx="77" cy="18" r=".22" fill="currentColor"/>
  <circle cx="78" cy="18" r=".22" fill="currentColor"/>
  <circle cx="79" cy="18" r=".22" fill="currentColor"/>
  <circle cx="82" cy="18" r=".22" fill="currentColor"/>
  <circle cx="83" cy="18" r=".22" fill="currentColor"/>
  <circle cx="84" cy="18" r=".22" fill="currentColor"/>
  <circle cx="85" cy="18" r=".22" fill="currentColor"/>
  <circle cx="86" cy="18" r=".22" fill="currentColor"/>
  <circle cx="87" cy="18" r=".22" fill="currentColor"/>
  <circle cx="88" cy="18" r=".22" fill="currentColor"/>
  <circle cx="89" cy="18" r=".22" fill="currentColor"/>
  <circle cx="90" cy="18" r=".22" fill="currentColor"/>
  <circle cx="91" cy="18" r=".22" fill="currentColor"/>
  <circle cx="92" cy="18" r=".22" fill="currentColor"/>
  <circle cx="93" cy="18" r=".22" fill="currentColor"/>
  <circle cx="94" cy="18" r=".22" fill="currentColor"/>
  <circle cx="95" cy="18" r=".22" fill="currentColor"/>
  <circle cx="96" cy="18" r=".22" fill="currentColor"/>
  <circle cx="97" cy="18" r=".22" fill="currentColor"/>
  <circle cx="98" cy="18" r=".22" fill="currentColor"/>
  <circle cx="99" cy="18" r=".22" fill="currentColor"/>
  <circle cx="100" cy="18" r=".22" fill="currentColor"/>
  <circle cx="101" cy="18" r=".22" fill="currentColor"/>
  <circle cx="102" cy="18" r=".22" fill="currentColor"/>
  <circle cx="103" cy="18" r=".22" fill="currentColor"/>
  <circle cx="104" cy="18" r=".22" fill="currentColor"/>
  <circle cx="105" cy="18" r=".22" fill="currentColor"/>
  <circle cx="106" cy="18" r=".22" fill="currentColor"/>
  <circle cx="107" cy="18" r=".22" fill="currentColor"/>
  <circle cx="108" cy="18" r=".22" fill="currentColor"/>
  <circle cx="109" cy="18" r=".22" fill="currentColor"/>
  <circle cx="110" cy="18" r=".22" fill="currentColor"/>
  <circle cx="111" cy="18" r=".22" fill="currentColor"/>
  <circle cx="20" cy="19" r=".22" fill="currentColor"/>
  <circle cx="21" cy="19" r=".22" fill="currentColor"/>
  <circle cx="22" cy="19" r=".22" fill="currentColor"/>
  <circle cx="23" cy="19" r=".22" fill="currentColor"/>
  <circle cx="24" cy="19" r=".22" fill="currentColor"/>
  <circle cx="25" cy="19" r=".22" fill="currentColor"/>
  <circle cx="26" cy="19" r=".22" fill="currentColor"/>
  <circle cx="27" cy="19" r=".22" fill="currentColor"/>
  <circle cx="28" cy="19" r=".22" fill="currentColor"/>
  <circle cx="29" cy="19" r=".22" fill="currentColor"/>
  <circle cx="30" cy="19" r=".22" fill="currentColor"/>
  <circle cx="31" cy="19" r=".22" fill="currentColor"/>
  <circle cx="32" cy="19" r=".22" fill="currentColor"/>
  <circle cx="33" cy="19" r=".22" fill="currentColor"/>
  <circle cx="34" cy="19" r=".22" fill="currentColor"/>
  <circle cx="35" cy="19" r=".22" fill="currentColor"/>
  <circle cx="36" cy="19" r=".22" fill="currentColor"/>
  <circle cx="37" cy="19" r=".22" fill="currentColor"/>
  <circle cx="38" cy="19" r=".22" fill="currentColor"/>
  <circle cx="40" cy="19" r=".22" fill="currentColor"/>
  <circle cx="61" cy="19" r=".22" fill="currentColor"/>
  <circle cx="63" cy="19" r=".22" fill="currentColor"/>
  <circle cx="64" cy="19" r=".22" fill="currentColor"/>
  <circle cx="65" cy="19" r=".22" fill="currentColor"/>
  <circle cx="67" cy="19" r=".22" fill="currentColor"/>
  <circle cx="69" cy="19" r=".22" fill="currentColor"/>
  <circle cx="70" cy="19" r=".22" fill="currentColor"/>
  <circle cx="71" cy="19" r=".22" fill="currentColor"/>
  <circle cx="72" cy="19" r=".22" fill="currentColor"/>
  <circle cx="77" cy="19" r=".22" fill="currentColor"/>
  <circle cx="78" cy="19" r=".22" fill="currentColor"/>
  <circle cx="79" cy="19" r=".22" fill="currentColor"/>
  <circle cx="81" cy="19" r=".22" fill="currentColor"/>
  <circle cx="82" cy="19" r=".22" fill="currentColor"/>
  <circle cx="83" cy="19" r=".22" fill="currentColor"/>
  <circle cx="84" cy="19" r=".22" fill="currentColor"/>
  <circle cx="85" cy="19" r=".22" fill="currentColor"/>
  <circle cx="86" cy="19" r=".22" fill="currentColor"/>
  <circle cx="87" cy="19" r=".22" fill="currentColor"/>
  <circle cx="88" cy="19" r=".22" fill="currentColor"/>
  <circle cx="89" cy="19" r=".22" fill="currentColor"/>
  <circle cx="90" cy="19" r=".22" fill="currentColor"/>
  <circle cx="91" cy="19" r=".22" fill="currentColor"/>
  <circle cx="92" cy="19" r=".22" fill="currentColor"/>
  <circle cx="93" cy="19" r=".22" fill="currentColor"/>
  <circle cx="94" cy="19" r=".22" fill="currentColor"/>
  <circle cx="95" cy="19" r=".22" fill="currentColor"/>
  <circle cx="96" cy="19" r=".22" fill="currentColor"/>
  <circle cx="97" cy="19" r=".22" fill="currentColor"/>
  <circle cx="98" cy="19" r=".22" fill="currentColor"/>
  <circle cx="99" cy="19" r=".22" fill="currentColor"/>
  <circle cx="100" cy="19" r=".22" fill="currentColor"/>
  <circle cx="101" cy="19" r=".22" fill="currentColor"/>
  <circle cx="102" cy="19" r=".22" fill="currentColor"/>
  <circle cx="103" cy="19" r=".22" fill="currentColor"/>
  <circle cx="104" cy="19" r=".22" fill="currentColor"/>
  <circle cx="105" cy="19" r=".22" fill="currentColor"/>
  <circle cx="106" cy="19" r=".22" fill="currentColor"/>
  <circle cx="107" cy="19" r=".22" fill="currentColor"/>
  <circle cx="108" cy="19" r=".22" fill="currentColor"/>
  <circle cx="109" cy="19" r=".22" fill="currentColor"/>
  <circle cx="110" cy="19" r=".22" fill="currentColor"/>
  <circle cx="113" cy="19" r=".22" fill="currentColor"/>
  <circle cx="114" cy="19" r=".22" fill="currentColor"/>
  <circle cx="20" cy="20" r=".22" fill="currentColor"/>
  <circle cx="21" cy="20" r=".22" fill="currentColor"/>
  <circle cx="22" cy="20" r=".22" fill="currentColor"/>
  <circle cx="23" cy="20" r=".22" fill="currentColor"/>
  <circle cx="24" cy="20" r=".22" fill="currentColor"/>
  <circle cx="25" cy="20" r=".22" fill="currentColor"/>
  <circle cx="26" cy="20" r=".22" fill="currentColor"/>
  <circle cx="27" cy="20" r=".22" fill="currentColor"/>
  <circle cx="28" cy="20" r=".22" fill="currentColor"/>
  <circle cx="29" cy="20" r=".22" fill="currentColor"/>
  <circle cx="30" cy="20" r=".22" fill="currentColor"/>
  <circle cx="31" cy="20" r=".22" fill="currentColor"/>
  <circle cx="32" cy="20" r=".22" fill="currentColor"/>
  <circle cx="33" cy="20" r=".22" fill="currentColor"/>
  <circle cx="34" cy="20" r=".22" fill="currentColor"/>
  <circle cx="35" cy="20" r=".22" fill="currentColor"/>
  <circle cx="36" cy="20" r=".22" fill="currentColor"/>
  <circle cx="60" cy="20" r=".22" fill="currentColor"/>
  <circle cx="61" cy="20" r=".22" fill="currentColor"/>
  <circle cx="62" cy="20" r=".22" fill="currentColor"/>
  <circle cx="63" cy="20" r=".22" fill="currentColor"/>
  <circle cx="68" cy="20" r=".22" fill="currentColor"/>
  <circle cx="70" cy="20" r=".22" fill="currentColor"/>
  <circle cx="71" cy="20" r=".22" fill="currentColor"/>
  <circle cx="72" cy="20" r=".22" fill="currentColor"/>
  <circle cx="73" cy="20" r=".22" fill="currentColor"/>
  <circle cx="75" cy="20" r=".22" fill="currentColor"/>
  <circle cx="78" cy="20" r=".22" fill="currentColor"/>
  <circle cx="79" cy="20" r=".22" fill="currentColor"/>
  <circle cx="80" cy="20" r=".22" fill="currentColor"/>
  <circle cx="83" cy="20" r=".22" fill="currentColor"/>
  <circle cx="84" cy="20" r=".22" fill="currentColor"/>
  <circle cx="85" cy="20" r=".22" fill="currentColor"/>
  <circle cx="86" cy="20" r=".22" fill="currentColor"/>
  <circle cx="87" cy="20" r=".22" fill="currentColor"/>
  <circle cx="88" cy="20" r=".22" fill="currentColor"/>
  <circle cx="89" cy="20" r=".22" fill="currentColor"/>
  <circle cx="90" cy="20" r=".22" fill="currentColor"/>
  <circle cx="91" cy="20" r=".22" fill="currentColor"/>
  <circle cx="92" cy="20" r=".22" fill="currentColor"/>
  <circle cx="93" cy="20" r=".22" fill="currentColor"/>
  <circle cx="94" cy="20" r=".22" fill="currentColor"/>
  <circle cx="95" cy="20" r=".22" fill="currentColor"/>
  <circle cx="96" cy="20" r=".22" fill="currentColor"/>
  <circle cx="97" cy="20" r=".22" fill="currentColor"/>
  <circle cx="98" cy="20" r=".22" fill="currentColor"/>
  <circle cx="99" cy="20" r=".22" fill="currentColor"/>
  <circle cx="100" cy="20" r=".22" fill="currentColor"/>
  <circle cx="101" cy="20" r=".22" fill="currentColor"/>
  <circle cx="102" cy="20" r=".22" fill="currentColor"/>
  <circle cx="103" cy="20" r=".22" fill="currentColor"/>
  <circle cx="104" cy="20" r=".22" fill="currentColor"/>
  <circle cx="105" cy="20" r=".22" fill="currentColor"/>
  <circle cx="106" cy="20" r=".22" fill="currentColor"/>
  <circle cx="107" cy="20" r=".22" fill="currentColor"/>
  <circle cx="108" cy="20" r=".22" fill="currentColor"/>
  <circle cx="20" cy="21" r=".22" fill="currentColor"/>
  <circle cx="21" cy="21" r=".22" fill="currentColor"/>
  <circle cx="22" cy="21" r=".22" fill="currentColor"/>
  <circle cx="23" cy="21" r=".22" fill="currentColor"/>
  <circle cx="24" cy="21" r=".22" fill="currentColor"/>
  <circle cx="25" cy="21" r=".22" fill="currentColor"/>
  <circle cx="26" cy="21" r=".22" fill="currentColor"/>
  <circle cx="27" cy="21" r=".22" fill="currentColor"/>
  <circle cx="28" cy="21" r=".22" fill="currentColor"/>
  <circle cx="29" cy="21" r=".22" fill="currentColor"/>
  <circle cx="30" cy="21" r=".22" fill="currentColor"/>
  <circle cx="31" cy="21" r=".22" fill="currentColor"/>
  <circle cx="32" cy="21" r=".22" fill="currentColor"/>
  <circle cx="33" cy="21" r=".22" fill="currentColor"/>
  <circle cx="34" cy="21" r=".22" fill="currentColor"/>
  <circle cx="35" cy="21" r=".22" fill="currentColor"/>
  <circle cx="36" cy="21" r=".22" fill="currentColor"/>
  <circle cx="60" cy="21" r=".22" fill="currentColor"/>
  <circle cx="61" cy="21" r=".22" fill="currentColor"/>
  <circle cx="62" cy="21" r=".22" fill="currentColor"/>
  <circle cx="66" cy="21" r=".22" fill="currentColor"/>
  <circle cx="69" cy="21" r=".22" fill="currentColor"/>
  <circle cx="71" cy="21" r=".22" fill="currentColor"/>
  <circle cx="73" cy="21" r=".22" fill="currentColor"/>
  <circle cx="74" cy="21" r=".22" fill="currentColor"/>
  <circle cx="75" cy="21" r=".22" fill="currentColor"/>
  <circle cx="76" cy="21" r=".22" fill="currentColor"/>
  <circle cx="77" cy="21" r=".22" fill="currentColor"/>
  <circle cx="78" cy="21" r=".22" fill="currentColor"/>
  <circle cx="79" cy="21" r=".22" fill="currentColor"/>
  <circle cx="80" cy="21" r=".22" fill="currentColor"/>
  <circle cx="82" cy="21" r=".22" fill="currentColor"/>
  <circle cx="83" cy="21" r=".22" fill="currentColor"/>
  <circle cx="84" cy="21" r=".22" fill="currentColor"/>
  <circle cx="85" cy="21" r=".22" fill="currentColor"/>
  <circle cx="86" cy="21" r=".22" fill="currentColor"/>
  <circle cx="87" cy="21" r=".22" fill="currentColor"/>
  <circle cx="88" cy="21" r=".22" fill="currentColor"/>
  <circle cx="89" cy="21" r=".22" fill="currentColor"/>
  <circle cx="90" cy="21" r=".22" fill="currentColor"/>
  <circle cx="91" cy="21" r=".22" fill="currentColor"/>
  <circle cx="92" cy="21" r=".22" fill="currentColor"/>
  <circle cx="93" cy="21" r=".22" fill="currentColor"/>
  <circle cx="94" cy="21" r=".22" fill="currentColor"/>
  <circle cx="95" cy="21" r=".22" fill="currentColor"/>
  <circle cx="96" cy="21" r=".22" fill="currentColor"/>
  <circle cx="97" cy="21" r=".22" fill="currentColor"/>
  <circle cx="98" cy="21" r=".22" fill="currentColor"/>
  <circle cx="99" cy="21" r=".22" fill="currentColor"/>
  <circle cx="100" cy="21" r=".22" fill="currentColor"/>
  <circle cx="101" cy="21" r=".22" fill="currentColor"/>
  <circle cx="102" cy="21" r=".22" fill="currentColor"/>
  <circle cx="103" cy="21" r=".22" fill="currentColor"/>
  <circle cx="104" cy="21" r=".22" fill="currentColor"/>
  <circle cx="106" cy="21" r=".22" fill="currentColor"/>
  <circle cx="21" cy="22" r=".22" fill="currentColor"/>
  <circle cx="22" cy="22" r=".22" fill="currentColor"/>
  <circle cx="23" cy="22" r=".22" fill="currentColor"/>
  <circle cx="24" cy="22" r=".22" fill="currentColor"/>
  <circle cx="25" cy="22" r=".22" fill="currentColor"/>
  <circle cx="26" cy="22" r=".22" fill="currentColor"/>
  <circle cx="27" cy="22" r=".22" fill="currentColor"/>
  <circle cx="28" cy="22" r=".22" fill="currentColor"/>
  <circle cx="29" cy="22" r=".22" fill="currentColor"/>
  <circle cx="30" cy="22" r=".22" fill="currentColor"/>
  <circle cx="31" cy="22" r=".22" fill="currentColor"/>
  <circle cx="32" cy="22" r=".22" fill="currentColor"/>
  <circle cx="33" cy="22" r=".22" fill="currentColor"/>
  <circle cx="34" cy="22" r=".22" fill="currentColor"/>
  <circle cx="35" cy="22" r=".22" fill="currentColor"/>
  <circle cx="36" cy="22" r=".22" fill="currentColor"/>
  <circle cx="60" cy="22" r=".22" fill="currentColor"/>
  <circle cx="61" cy="22" r=".22" fill="currentColor"/>
  <circle cx="62" cy="22" r=".22" fill="currentColor"/>
  <circle cx="68" cy="22" r=".22" fill="currentColor"/>
  <circle cx="71" cy="22" r=".22" fill="currentColor"/>
  <circle cx="73" cy="22" r=".22" fill="currentColor"/>
  <circle cx="74" cy="22" r=".22" fill="currentColor"/>
  <circle cx="75" cy="22" r=".22" fill="currentColor"/>
  <circle cx="76" cy="22" r=".22" fill="currentColor"/>
  <circle cx="77" cy="22" r=".22" fill="currentColor"/>
  <circle cx="78" cy="22" r=".22" fill="currentColor"/>
  <circle cx="79" cy="22" r=".22" fill="currentColor"/>
  <circle cx="80" cy="22" r=".22" fill="currentColor"/>
  <circle cx="82" cy="22" r=".22" fill="currentColor"/>
  <circle cx="83" cy="22" r=".22" fill="currentColor"/>
  <circle cx="84" cy="22" r=".22" fill="currentColor"/>
  <circle cx="85" cy="22" r=".22" fill="currentColor"/>
  <circle cx="86" cy="22" r=".22" fill="currentColor"/>
  <circle cx="87" cy="22" r=".22" fill="currentColor"/>
  <circle cx="88" cy="22" r=".22" fill="currentColor"/>
  <circle cx="89" cy="22" r=".22" fill="currentColor"/>
  <circle cx="90" cy="22" r=".22" fill="currentColor"/>
  <circle cx="91" cy="22" r=".22" fill="currentColor"/>
  <circle cx="92" cy="22" r=".22" fill="currentColor"/>
  <circle cx="93" cy="22" r=".22" fill="currentColor"/>
  <circle cx="94" cy="22" r=".22" fill="currentColor"/>
  <circle cx="95" cy="22" r=".22" fill="currentColor"/>
  <circle cx="96" cy="22" r=".22" fill="currentColor"/>
  <circle cx="97" cy="22" r=".22" fill="currentColor"/>
  <circle cx="98" cy="22" r=".22" fill="currentColor"/>
  <circle cx="99" cy="22" r=".22" fill="currentColor"/>
  <circle cx="100" cy="22" r=".22" fill="currentColor"/>
  <circle cx="101" cy="22" r=".22" fill="currentColor"/>
  <circle cx="102" cy="22" r=".22" fill="currentColor"/>
  <circle cx="103" cy="22" r=".22" fill="currentColor"/>
  <circle cx="104" cy="22" r=".22" fill="currentColor"/>
  <circle cx="105" cy="22" r=".22" fill="currentColor"/>
  <circle cx="106" cy="22" r=".22" fill="currentColor"/>
  <circle cx="108" cy="22" r=".22" fill="currentColor"/>
  <circle cx="112" cy="22" r=".22" fill="currentColor"/>
  <circle cx="21" cy="23" r=".22" fill="currentColor"/>
  <circle cx="22" cy="23" r=".22" fill="currentColor"/>
  <circle cx="23" cy="23" r=".22" fill="currentColor"/>
  <circle cx="24" cy="23" r=".22" fill="currentColor"/>
  <circle cx="25" cy="23" r=".22" fill="currentColor"/>
  <circle cx="26" cy="23" r=".22" fill="currentColor"/>
  <circle cx="27" cy="23" r=".22" fill="currentColor"/>
  <circle cx="28" cy="23" r=".22" fill="currentColor"/>
  <circle cx="29" cy="23" r=".22" fill="currentColor"/>
  <circle cx="30" cy="23" r=".22" fill="currentColor"/>
  <circle cx="31" cy="23" r=".22" fill="currentColor"/>
  <circle cx="32" cy="23" r=".22" fill="currentColor"/>
  <circle cx="33" cy="23" r=".22" fill="currentColor"/>
  <circle cx="34" cy="23" r=".22" fill="currentColor"/>
  <circle cx="35" cy="23" r=".22" fill="currentColor"/>
  <circle cx="36" cy="23" r=".22" fill="currentColor"/>
  <circle cx="61" cy="23" r=".22" fill="currentColor"/>
  <circle cx="62" cy="23" r=".22" fill="currentColor"/>
  <circle cx="63" cy="23" r=".22" fill="currentColor"/>
  <circle cx="64" cy="23" r=".22" fill="currentColor"/>
  <circle cx="65" cy="23" r=".22" fill="currentColor"/>
  <circle cx="66" cy="23" r=".22" fill="currentColor"/>
  <circle cx="76" cy="23" r=".22" fill="currentColor"/>
  <circle cx="77" cy="23" r=".22" fill="currentColor"/>
  <circle cx="78" cy="23" r=".22" fill="currentColor"/>
  <circle cx="79" cy="23" r=".22" fill="currentColor"/>
  <circle cx="80" cy="23" r=".22" fill="currentColor"/>
  <circle cx="81" cy="23" r=".22" fill="currentColor"/>
  <circle cx="82" cy="23" r=".22" fill="currentColor"/>
  <circle cx="83" cy="23" r=".22" fill="currentColor"/>
  <circle cx="84" cy="23" r=".22" fill="currentColor"/>
  <circle cx="85" cy="23" r=".22" fill="currentColor"/>
  <circle cx="86" cy="23" r=".22" fill="currentColor"/>
  <circle cx="87" cy="23" r=".22" fill="currentColor"/>
  <circle cx="88" cy="23" r=".22" fill="currentColor"/>
  <circle cx="89" cy="23" r=".22" fill="currentColor"/>
  <circle cx="90" cy="23" r=".22" fill="currentColor"/>
  <circle cx="91" cy="23" r=".22" fill="currentColor"/>
  <circle cx="92" cy="23" r=".22" fill="currentColor"/>
  <circle cx="93" cy="23" r=".22" fill="currentColor"/>
  <circle cx="94" cy="23" r=".22" fill="currentColor"/>
  <circle cx="95" cy="23" r=".22" fill="currentColor"/>
  <circle cx="96" cy="23" r=".22" fill="currentColor"/>
  <circle cx="97" cy="23" r=".22" fill="currentColor"/>
  <circle cx="98" cy="23" r=".22" fill="currentColor"/>
  <circle cx="99" cy="23" r=".22" fill="currentColor"/>
  <circle cx="100" cy="23" r=".22" fill="currentColor"/>
  <circle cx="101" cy="23" r=".22" fill="currentColor"/>
  <circle cx="102" cy="23" r=".22" fill="currentColor"/>
  <circle cx="103" cy="23" r=".22" fill="currentColor"/>
  <circle cx="104" cy="23" r=".22" fill="currentColor"/>
  <circle cx="105" cy="23" r=".22" fill="currentColor"/>
  <circle cx="108" cy="23" r=".22" fill="currentColor"/>
  <circle cx="110" cy="23" r=".22" fill="currentColor"/>
  <circle cx="111" cy="23" r=".22" fill="currentColor"/>
  <circle cx="22" cy="24" r=".22" fill="currentColor"/>
  <circle cx="23" cy="24" r=".22" fill="currentColor"/>
  <circle cx="24" cy="24" r=".22" fill="currentColor"/>
  <circle cx="25" cy="24" r=".22" fill="currentColor"/>
  <circle cx="26" cy="24" r=".22" fill="currentColor"/>
  <circle cx="27" cy="24" r=".22" fill="currentColor"/>
  <circle cx="28" cy="24" r=".22" fill="currentColor"/>
  <circle cx="29" cy="24" r=".22" fill="currentColor"/>
  <circle cx="30" cy="24" r=".22" fill="currentColor"/>
  <circle cx="31" cy="24" r=".22" fill="currentColor"/>
  <circle cx="32" cy="24" r=".22" fill="currentColor"/>
  <circle cx="33" cy="24" r=".22" fill="currentColor"/>
  <circle cx="34" cy="24" r=".22" fill="currentColor"/>
  <circle cx="60" cy="24" r=".22" fill="currentColor"/>
  <circle cx="61" cy="24" r=".22" fill="currentColor"/>
  <circle cx="62" cy="24" r=".22" fill="currentColor"/>
  <circle cx="63" cy="24" r=".22" fill="currentColor"/>
  <circle cx="64" cy="24" r=".22" fill="currentColor"/>
  <circle cx="65" cy="24" r=".22" fill="currentColor"/>
  <circle cx="66" cy="24" r=".22" fill="currentColor"/>
  <circle cx="67" cy="24" r=".22" fill="currentColor"/>
  <circle cx="68" cy="24" r=".22" fill="currentColor"/>
  <circle cx="71" cy="24" r=".22" fill="currentColor"/>
  <circle cx="76" cy="24" r=".22" fill="currentColor"/>
  <circle cx="77" cy="24" r=".22" fill="currentColor"/>
  <circle cx="78" cy="24" r=".22" fill="currentColor"/>
  <circle cx="79" cy="24" r=".22" fill="currentColor"/>
  <circle cx="80" cy="24" r=".22" fill="currentColor"/>
  <circle cx="81" cy="24" r=".22" fill="currentColor"/>
  <circle cx="82" cy="24" r=".22" fill="currentColor"/>
  <circle cx="83" cy="24" r=".22" fill="currentColor"/>
  <circle cx="84" cy="24" r=".22" fill="currentColor"/>
  <circle cx="85" cy="24" r=".22" fill="currentColor"/>
  <circle cx="86" cy="24" r=".22" fill="currentColor"/>
  <circle cx="87" cy="24" r=".22" fill="currentColor"/>
  <circle cx="88" cy="24" r=".22" fill="currentColor"/>
  <circle cx="89" cy="24" r=".22" fill="currentColor"/>
  <circle cx="90" cy="24" r=".22" fill="currentColor"/>
  <circle cx="91" cy="24" r=".22" fill="currentColor"/>
  <circle cx="92" cy="24" r=".22" fill="currentColor"/>
  <circle cx="93" cy="24" r=".22" fill="currentColor"/>
  <circle cx="94" cy="24" r=".22" fill="currentColor"/>
  <circle cx="95" cy="24" r=".22" fill="currentColor"/>
  <circle cx="96" cy="24" r=".22" fill="currentColor"/>
  <circle cx="97" cy="24" r=".22" fill="currentColor"/>
  <circle cx="98" cy="24" r=".22" fill="currentColor"/>
  <circle cx="99" cy="24" r=".22" fill="currentColor"/>
  <circle cx="100" cy="24" r=".22" fill="currentColor"/>
  <circle cx="101" cy="24" r=".22" fill="currentColor"/>
  <circle cx="102" cy="24" r=".22" fill="currentColor"/>
  <circle cx="103" cy="24" r=".22" fill="currentColor"/>
  <circle cx="104" cy="24" r=".22" fill="currentColor"/>
  <circle cx="105" cy="24" r=".22" fill="currentColor"/>
  <circle cx="109" cy="24" r=".22" fill="currentColor"/>
  <circle cx="24" cy="25" r=".22" fill="currentColor"/>
  <circle cx="25" cy="25" r=".22" fill="currentColor"/>
  <circle cx="26" cy="25" r=".22" fill="currentColor"/>
  <circle cx="27" cy="25" r=".22" fill="currentColor"/>
  <circle cx="28" cy="25" r=".22" fill="currentColor"/>
  <circle cx="29" cy="25" r=".22" fill="currentColor"/>
  <circle cx="30" cy="25" r=".22" fill="currentColor"/>
  <circle cx="31" cy="25" r=".22" fill="currentColor"/>
  <circle cx="33" cy="25" r=".22" fill="currentColor"/>
  <circle cx="34" cy="25" r=".22" fill="currentColor"/>
  <circle cx="60" cy="25" r=".22" fill="currentColor"/>
  <circle cx="61" cy="25" r=".22" fill="currentColor"/>
  <circle cx="62" cy="25" r=".22" fill="currentColor"/>
  <circle cx="63" cy="25" r=".22" fill="currentColor"/>
  <circle cx="64" cy="25" r=".22" fill="currentColor"/>
  <circle cx="65" cy="25" r=".22" fill="currentColor"/>
  <circle cx="66" cy="25" r=".22" fill="currentColor"/>
  <circle cx="67" cy="25" r=".22" fill="currentColor"/>
  <circle cx="68" cy="25" r=".22" fill="currentColor"/>
  <circle cx="69" cy="25" r=".22" fill="currentColor"/>
  <circle cx="70" cy="25" r=".22" fill="currentColor"/>
  <circle cx="71" cy="25" r=".22" fill="currentColor"/>
  <circle cx="72" cy="25" r=".22" fill="currentColor"/>
  <circle cx="73" cy="25" r=".22" fill="currentColor"/>
  <circle cx="74" cy="25" r=".22" fill="currentColor"/>
  <circle cx="75" cy="25" r=".22" fill="currentColor"/>
  <circle cx="76" cy="25" r=".22" fill="currentColor"/>
  <circle cx="77" cy="25" r=".22" fill="currentColor"/>
  <circle cx="78" cy="25" r=".22" fill="currentColor"/>
  <circle cx="79" cy="25" r=".22" fill="currentColor"/>
  <circle cx="80" cy="25" r=".22" fill="currentColor"/>
  <circle cx="81" cy="25" r=".22" fill="currentColor"/>
  <circle cx="82" cy="25" r=".22" fill="currentColor"/>
  <circle cx="83" cy="25" r=".22" fill="currentColor"/>
  <circle cx="84" cy="25" r=".22" fill="currentColor"/>
  <circle cx="85" cy="25" r=".22" fill="currentColor"/>
  <circle cx="86" cy="25" r=".22" fill="currentColor"/>
  <circle cx="87" cy="25" r=".22" fill="currentColor"/>
  <circle cx="88" cy="25" r=".22" fill="currentColor"/>
  <circle cx="89" cy="25" r=".22" fill="currentColor"/>
  <circle cx="90" cy="25" r=".22" fill="currentColor"/>
  <circle cx="91" cy="25" r=".22" fill="currentColor"/>
  <circle cx="92" cy="25" r=".22" fill="currentColor"/>
  <circle cx="93" cy="25" r=".22" fill="currentColor"/>
  <circle cx="94" cy="25" r=".22" fill="currentColor"/>
  <circle cx="95" cy="25" r=".22" fill="currentColor"/>
  <circle cx="96" cy="25" r=".22" fill="currentColor"/>
  <circle cx="97" cy="25" r=".22" fill="currentColor"/>
  <circle cx="98" cy="25" r=".22" fill="currentColor"/>
  <circle cx="99" cy="25" r=".22" fill="currentColor"/>
  <circle cx="100" cy="25" r=".22" fill="currentColor"/>
  <circle cx="101" cy="25" r=".22" fill="currentColor"/>
  <circle cx="102" cy="25" r=".22" fill="currentColor"/>
  <circle cx="103" cy="25" r=".22" fill="currentColor"/>
  <circle cx="104" cy="25" r=".22" fill="currentColor"/>
  <circle cx="105" cy="25" r=".22" fill="currentColor"/>
  <circle cx="23" cy="26" r=".22" fill="currentColor"/>
  <circle cx="25" cy="26" r=".22" fill="currentColor"/>
  <circle cx="26" cy="26" r=".22" fill="currentColor"/>
  <circle cx="27" cy="26" r=".22" fill="currentColor"/>
  <circle cx="28" cy="26" r=".22" fill="currentColor"/>
  <circle cx="34" cy="26" r=".22" fill="currentColor"/>
  <circle cx="59" cy="26" r=".22" fill="currentColor"/>
  <circle cx="60" cy="26" r=".22" fill="currentColor"/>
  <circle cx="61" cy="26" r=".22" fill="currentColor"/>
  <circle cx="62" cy="26" r=".22" fill="currentColor"/>
  <circle cx="63" cy="26" r=".22" fill="currentColor"/>
  <circle cx="64" cy="26" r=".22" fill="currentColor"/>
  <circle cx="65" cy="26" r=".22" fill="currentColor"/>
  <circle cx="66" cy="26" r=".22" fill="currentColor"/>
  <circle cx="67" cy="26" r=".22" fill="currentColor"/>
  <circle cx="68" cy="26" r=".22" fill="currentColor"/>
  <circle cx="69" cy="26" r=".22" fill="currentColor"/>
  <circle cx="70" cy="26" r=".22" fill="currentColor"/>
  <circle cx="71" cy="26" r=".22" fill="currentColor"/>
  <circle cx="72" cy="26" r=".22" fill="currentColor"/>
  <circle cx="73" cy="26" r=".22" fill="currentColor"/>
  <circle cx="74" cy="26" r=".22" fill="currentColor"/>
  <circle cx="76" cy="26" r=".22" fill="currentColor"/>
  <circle cx="77" cy="26" r=".22" fill="currentColor"/>
  <circle cx="78" cy="26" r=".22" fill="currentColor"/>
  <circle cx="79" cy="26" r=".22" fill="currentColor"/>
  <circle cx="80" cy="26" r=".22" fill="currentColor"/>
  <circle cx="82" cy="26" r=".22" fill="currentColor"/>
  <circle cx="83" cy="26" r=".22" fill="currentColor"/>
  <circle cx="84" cy="26" r=".22" fill="currentColor"/>
  <circle cx="85" cy="26" r=".22" fill="currentColor"/>
  <circle cx="86" cy="26" r=".22" fill="currentColor"/>
  <circle cx="87" cy="26" r=".22" fill="currentColor"/>
  <circle cx="88" cy="26" r=".22" fill="currentColor"/>
  <circle cx="89" cy="26" r=".22" fill="currentColor"/>
  <circle cx="90" cy="26" r=".22" fill="currentColor"/>
  <circle cx="91" cy="26" r=".22" fill="currentColor"/>
  <circle cx="92" cy="26" r=".22" fill="currentColor"/>
  <circle cx="93" cy="26" r=".22" fill="currentColor"/>
  <circle cx="94" cy="26" r=".22" fill="currentColor"/>
  <circle cx="95" cy="26" r=".22" fill="currentColor"/>
  <circle cx="96" cy="26" r=".22" fill="currentColor"/>
  <circle cx="97" cy="26" r=".22" fill="currentColor"/>
  <circle cx="98" cy="26" r=".22" fill="currentColor"/>
  <circle cx="99" cy="26" r=".22" fill="currentColor"/>
  <circle cx="100" cy="26" r=".22" fill="currentColor"/>
  <circle cx="101" cy="26" r=".22" fill="currentColor"/>
  <circle cx="102" cy="26" r=".22" fill="currentColor"/>
  <circle cx="103" cy="26" r=".22" fill="currentColor"/>
  <circle cx="104" cy="26" r=".22" fill="currentColor"/>
  <circle cx="105" cy="26" r=".22" fill="currentColor"/>
  <circle cx="24" cy="27" r=".22" fill="currentColor"/>
  <circle cx="25" cy="27" r=".22" fill="currentColor"/>
  <circle cx="26" cy="27" r=".22" fill="currentColor"/>
  <circle cx="27" cy="27" r=".22" fill="currentColor"/>
  <circle cx="28" cy="27" r=".22" fill="currentColor"/>
  <circle cx="58" cy="27" r=".22" fill="currentColor"/>
  <circle cx="59" cy="27" r=".22" fill="currentColor"/>
  <circle cx="60" cy="27" r=".22" fill="currentColor"/>
  <circle cx="61" cy="27" r=".22" fill="currentColor"/>
  <circle cx="62" cy="27" r=".22" fill="currentColor"/>
  <circle cx="63" cy="27" r=".22" fill="currentColor"/>
  <circle cx="64" cy="27" r=".22" fill="currentColor"/>
  <circle cx="65" cy="27" r=".22" fill="currentColor"/>
  <circle cx="66" cy="27" r=".22" fill="currentColor"/>
  <circle cx="67" cy="27" r=".22" fill="currentColor"/>
  <circle cx="68" cy="27" r=".22" fill="currentColor"/>
  <circle cx="69" cy="27" r=".22" fill="currentColor"/>
  <circle cx="70" cy="27" r=".22" fill="currentColor"/>
  <circle cx="71" cy="27" r=".22" fill="currentColor"/>
  <circle cx="72" cy="27" r=".22" fill="currentColor"/>
  <circle cx="73" cy="27" r=".22" fill="currentColor"/>
  <circle cx="74" cy="27" r=".22" fill="currentColor"/>
  <circle cx="75" cy="27" r=".22" fill="currentColor"/>
  <circle cx="77" cy="27" r=".22" fill="currentColor"/>
  <circle cx="78" cy="27" r=".22" fill="currentColor"/>
  <circle cx="79" cy="27" r=".22" fill="currentColor"/>
  <circle cx="80" cy="27" r=".22" fill="currentColor"/>
  <circle cx="81" cy="27" r=".22" fill="currentColor"/>
  <circle cx="87" cy="27" r=".22" fill="currentColor"/>
  <circle cx="88" cy="27" r=".22" fill="currentColor"/>
  <circle cx="89" cy="27" r=".22" fill="currentColor"/>
  <circle cx="90" cy="27" r=".22" fill="currentColor"/>
  <circle cx="91" cy="27" r=".22" fill="currentColor"/>
  <circle cx="92" cy="27" r=".22" fill="currentColor"/>
  <circle cx="93" cy="27" r=".22" fill="currentColor"/>
  <circle cx="94" cy="27" r=".22" fill="currentColor"/>
  <circle cx="95" cy="27" r=".22" fill="currentColor"/>
  <circle cx="96" cy="27" r=".22" fill="currentColor"/>
  <circle cx="97" cy="27" r=".22" fill="currentColor"/>
  <circle cx="98" cy="27" r=".22" fill="currentColor"/>
  <circle cx="99" cy="27" r=".22" fill="currentColor"/>
  <circle cx="100" cy="27" r=".22" fill="currentColor"/>
  <circle cx="101" cy="27" r=".22" fill="currentColor"/>
  <circle cx="102" cy="27" r=".22" fill="currentColor"/>
  <circle cx="103" cy="27" r=".22" fill="currentColor"/>
  <circle cx="104" cy="27" r=".22" fill="currentColor"/>
  <circle cx="26" cy="28" r=".22" fill="currentColor"/>
  <circle cx="27" cy="28" r=".22" fill="currentColor"/>
  <circle cx="28" cy="28" r=".22" fill="currentColor"/>
  <circle cx="35" cy="28" r=".22" fill="currentColor"/>
  <circle cx="58" cy="28" r=".22" fill="currentColor"/>
  <circle cx="59" cy="28" r=".22" fill="currentColor"/>
  <circle cx="60" cy="28" r=".22" fill="currentColor"/>
  <circle cx="61" cy="28" r=".22" fill="currentColor"/>
  <circle cx="62" cy="28" r=".22" fill="currentColor"/>
  <circle cx="63" cy="28" r=".22" fill="currentColor"/>
  <circle cx="64" cy="28" r=".22" fill="currentColor"/>
  <circle cx="65" cy="28" r=".22" fill="currentColor"/>
  <circle cx="66" cy="28" r=".22" fill="currentColor"/>
  <circle cx="67" cy="28" r=".22" fill="currentColor"/>
  <circle cx="68" cy="28" r=".22" fill="currentColor"/>
  <circle cx="69" cy="28" r=".22" fill="currentColor"/>
  <circle cx="70" cy="28" r=".22" fill="currentColor"/>
  <circle cx="71" cy="28" r=".22" fill="currentColor"/>
  <circle cx="72" cy="28" r=".22" fill="currentColor"/>
  <circle cx="73" cy="28" r=".22" fill="currentColor"/>
  <circle cx="74" cy="28" r=".22" fill="currentColor"/>
  <circle cx="75" cy="28" r=".22" fill="currentColor"/>
  <circle cx="77" cy="28" r=".22" fill="currentColor"/>
  <circle cx="78" cy="28" r=".22" fill="currentColor"/>
  <circle cx="79" cy="28" r=".22" fill="currentColor"/>
  <circle cx="80" cy="28" r=".22" fill="currentColor"/>
  <circle cx="81" cy="28" r=".22" fill="currentColor"/>
  <circle cx="82" cy="28" r=".22" fill="currentColor"/>
  <circle cx="83" cy="28" r=".22" fill="currentColor"/>
  <circle cx="84" cy="28" r=".22" fill="currentColor"/>
  <circle cx="88" cy="28" r=".22" fill="currentColor"/>
  <circle cx="89" cy="28" r=".22" fill="currentColor"/>
  <circle cx="90" cy="28" r=".22" fill="currentColor"/>
  <circle cx="91" cy="28" r=".22" fill="currentColor"/>
  <circle cx="92" cy="28" r=".22" fill="currentColor"/>
  <circle cx="93" cy="28" r=".22" fill="currentColor"/>
  <circle cx="94" cy="28" r=".22" fill="currentColor"/>
  <circle cx="96" cy="28" r=".22" fill="currentColor"/>
  <circle cx="97" cy="28" r=".22" fill="currentColor"/>
  <circle cx="98" cy="28" r=".22" fill="currentColor"/>
  <circle cx="99" cy="28" r=".22" fill="currentColor"/>
  <circle cx="100" cy="28" r=".22" fill="currentColor"/>
  <circle cx="101" cy="28" r=".22" fill="currentColor"/>
  <circle cx="102" cy="28" r=".22" fill="currentColor"/>
  <circle cx="26" cy="29" r=".22" fill="currentColor"/>
  <circle cx="27" cy="29" r=".22" fill="currentColor"/>
  <circle cx="28" cy="29" r=".22" fill="currentColor"/>
  <circle cx="29" cy="29" r=".22" fill="currentColor"/>
  <circle cx="32" cy="29" r=".22" fill="currentColor"/>
  <circle cx="38" cy="29" r=".22" fill="currentColor"/>
  <circle cx="58" cy="29" r=".22" fill="currentColor"/>
  <circle cx="59" cy="29" r=".22" fill="currentColor"/>
  <circle cx="60" cy="29" r=".22" fill="currentColor"/>
  <circle cx="61" cy="29" r=".22" fill="currentColor"/>
  <circle cx="62" cy="29" r=".22" fill="currentColor"/>
  <circle cx="63" cy="29" r=".22" fill="currentColor"/>
  <circle cx="64" cy="29" r=".22" fill="currentColor"/>
  <circle cx="65" cy="29" r=".22" fill="currentColor"/>
  <circle cx="66" cy="29" r=".22" fill="currentColor"/>
  <circle cx="67" cy="29" r=".22" fill="currentColor"/>
  <circle cx="68" cy="29" r=".22" fill="currentColor"/>
  <circle cx="69" cy="29" r=".22" fill="currentColor"/>
  <circle cx="70" cy="29" r=".22" fill="currentColor"/>
  <circle cx="71" cy="29" r=".22" fill="currentColor"/>
  <circle cx="72" cy="29" r=".22" fill="currentColor"/>
  <circle cx="73" cy="29" r=".22" fill="currentColor"/>
  <circle cx="74" cy="29" r=".22" fill="currentColor"/>
  <circle cx="75" cy="29" r=".22" fill="currentColor"/>
  <circle cx="76" cy="29" r=".22" fill="currentColor"/>
  <circle cx="78" cy="29" r=".22" fill="currentColor"/>
  <circle cx="79" cy="29" r=".22" fill="currentColor"/>
  <circle cx="80" cy="29" r=".22" fill="currentColor"/>
  <circle cx="81" cy="29" r=".22" fill="currentColor"/>
  <circle cx="82" cy="29" r=".22" fill="currentColor"/>
  <circle cx="83" cy="29" r=".22" fill="currentColor"/>
  <circle cx="89" cy="29" r=".22" fill="currentColor"/>
  <circle cx="90" cy="29" r=".22" fill="currentColor"/>
  <circle cx="91" cy="29" r=".22" fill="currentColor"/>
  <circle cx="92" cy="29" r=".22" fill="currentColor"/>
  <circle cx="93" cy="29" r=".22" fill="currentColor"/>
  <circle cx="96" cy="29" r=".22" fill="currentColor"/>
  <circle cx="97" cy="29" r=".22" fill="currentColor"/>
  <circle cx="98" cy="29" r=".22" fill="currentColor"/>
  <circle cx="99" cy="29" r=".22" fill="currentColor"/>
  <circle cx="100" cy="29" r=".22" fill="currentColor"/>
  <circle cx="102" cy="29" r=".22" fill="currentColor"/>
  <circle cx="28" cy="30" r=".22" fill="currentColor"/>
  <circle cx="29" cy="30" r=".22" fill="currentColor"/>
  <circle cx="30" cy="30" r=".22" fill="currentColor"/>
  <circle cx="31" cy="30" r=".22" fill="currentColor"/>
  <circle cx="58" cy="30" r=".22" fill="currentColor"/>
  <circle cx="59" cy="30" r=".22" fill="currentColor"/>
  <circle cx="60" cy="30" r=".22" fill="currentColor"/>
  <circle cx="61" cy="30" r=".22" fill="currentColor"/>
  <circle cx="62" cy="30" r=".22" fill="currentColor"/>
  <circle cx="63" cy="30" r=".22" fill="currentColor"/>
  <circle cx="64" cy="30" r=".22" fill="currentColor"/>
  <circle cx="65" cy="30" r=".22" fill="currentColor"/>
  <circle cx="66" cy="30" r=".22" fill="currentColor"/>
  <circle cx="67" cy="30" r=".22" fill="currentColor"/>
  <circle cx="68" cy="30" r=".22" fill="currentColor"/>
  <circle cx="69" cy="30" r=".22" fill="currentColor"/>
  <circle cx="70" cy="30" r=".22" fill="currentColor"/>
  <circle cx="71" cy="30" r=".22" fill="currentColor"/>
  <circle cx="72" cy="30" r=".22" fill="currentColor"/>
  <circle cx="73" cy="30" r=".22" fill="currentColor"/>
  <circle cx="74" cy="30" r=".22" fill="currentColor"/>
  <circle cx="75" cy="30" r=".22" fill="currentColor"/>
  <circle cx="76" cy="30" r=".22" fill="currentColor"/>
  <circle cx="78" cy="30" r=".22" fill="currentColor"/>
  <circle cx="79" cy="30" r=".22" fill="currentColor"/>
  <circle cx="80" cy="30" r=".22" fill="currentColor"/>
  <circle cx="81" cy="30" r=".22" fill="currentColor"/>
  <circle cx="82" cy="30" r=".22" fill="currentColor"/>
  <circle cx="89" cy="30" r=".22" fill="currentColor"/>
  <circle cx="90" cy="30" r=".22" fill="currentColor"/>
  <circle cx="91" cy="30" r=".22" fill="currentColor"/>
  <circle cx="97" cy="30" r=".22" fill="currentColor"/>
  <circle cx="98" cy="30" r=".22" fill="currentColor"/>
  <circle cx="99" cy="30" r=".22" fill="currentColor"/>
  <circle cx="100" cy="30" r=".22" fill="currentColor"/>
  <circle cx="106" cy="30" r=".22" fill="currentColor"/>
  <circle cx="31" cy="31" r=".22" fill="currentColor"/>
  <circle cx="32" cy="31" r=".22" fill="currentColor"/>
  <circle cx="33" cy="31" r=".22" fill="currentColor"/>
  <circle cx="58" cy="31" r=".22" fill="currentColor"/>
  <circle cx="59" cy="31" r=".22" fill="currentColor"/>
  <circle cx="60" cy="31" r=".22" fill="currentColor"/>
  <circle cx="61" cy="31" r=".22" fill="currentColor"/>
  <circle cx="62" cy="31" r=".22" fill="currentColor"/>
  <circle cx="63" cy="31" r=".22" fill="currentColor"/>
  <circle cx="64" cy="31" r=".22" fill="currentColor"/>
  <circle cx="65" cy="31" r=".22" fill="currentColor"/>
  <circle cx="66" cy="31" r=".22" fill="currentColor"/>
  <circle cx="67" cy="31" r=".22" fill="currentColor"/>
  <circle cx="68" cy="31" r=".22" fill="currentColor"/>
  <circle cx="69" cy="31" r=".22" fill="currentColor"/>
  <circle cx="70" cy="31" r=".22" fill="currentColor"/>
  <circle cx="71" cy="31" r=".22" fill="currentColor"/>
  <circle cx="72" cy="31" r=".22" fill="currentColor"/>
  <circle cx="73" cy="31" r=".22" fill="currentColor"/>
  <circle cx="74" cy="31" r=".22" fill="currentColor"/>
  <circle cx="75" cy="31" r=".22" fill="currentColor"/>
  <circle cx="76" cy="31" r=".22" fill="currentColor"/>
  <circle cx="77" cy="31" r=".22" fill="currentColor"/>
  <circle cx="79" cy="31" r=".22" fill="currentColor"/>
  <circle cx="80" cy="31" r=".22" fill="currentColor"/>
  <circle cx="90" cy="31" r=".22" fill="currentColor"/>
  <circle cx="91" cy="31" r=".22" fill="currentColor"/>
  <circle cx="98" cy="31" r=".22" fill="currentColor"/>
  <circle cx="99" cy="31" r=".22" fill="currentColor"/>
  <circle cx="100" cy="31" r=".22" fill="currentColor"/>
  <circle cx="101" cy="31" r=".22" fill="currentColor"/>
  <circle cx="33" cy="32" r=".22" fill="currentColor"/>
  <circle cx="58" cy="32" r=".22" fill="currentColor"/>
  <circle cx="59" cy="32" r=".22" fill="currentColor"/>
  <circle cx="60" cy="32" r=".22" fill="currentColor"/>
  <circle cx="61" cy="32" r=".22" fill="currentColor"/>
  <circle cx="62" cy="32" r=".22" fill="currentColor"/>
  <circle cx="63" cy="32" r=".22" fill="currentColor"/>
  <circle cx="64" cy="32" r=".22" fill="currentColor"/>
  <circle cx="65" cy="32" r=".22" fill="currentColor"/>
  <circle cx="66" cy="32" r=".22" fill="currentColor"/>
  <circle cx="67" cy="32" r=".22" fill="currentColor"/>
  <circle cx="68" cy="32" r=".22" fill="currentColor"/>
  <circle cx="69" cy="32" r=".22" fill="currentColor"/>
  <circle cx="70" cy="32" r=".22" fill="currentColor"/>
  <circle cx="71" cy="32" r=".22" fill="currentColor"/>
  <circle cx="72" cy="32" r=".22" fill="currentColor"/>
  <circle cx="73" cy="32" r=".22" fill="currentColor"/>
  <circle cx="74" cy="32" r=".22" fill="currentColor"/>
  <circle cx="75" cy="32" r=".22" fill="currentColor"/>
  <circle cx="76" cy="32" r=".22" fill="currentColor"/>
  <circle cx="77" cy="32" r=".22" fill="currentColor"/>
  <circle cx="78" cy="32" r=".22" fill="currentColor"/>
  <circle cx="90" cy="32" r=".22" fill="currentColor"/>
  <circle cx="91" cy="32" r=".22" fill="currentColor"/>
  <circle cx="98" cy="32" r=".22" fill="currentColor"/>
  <circle cx="100" cy="32" r=".22" fill="currentColor"/>
  <circle cx="101" cy="32" r=".22" fill="currentColor"/>
  <circle cx="106" cy="32" r=".22" fill="currentColor"/>
  <circle cx="107" cy="32" r=".22" fill="currentColor"/>
  <circle cx="34" cy="33" r=".22" fill="currentColor"/>
  <circle cx="36" cy="33" r=".22" fill="currentColor"/>
  <circle cx="37" cy="33" r=".22" fill="currentColor"/>
  <circle cx="38" cy="33" r=".22" fill="currentColor"/>
  <circle cx="39" cy="33" r=".22" fill="currentColor"/>
  <circle cx="40" cy="33" r=".22" fill="currentColor"/>
  <circle cx="41" cy="33" r=".22" fill="currentColor"/>
  <circle cx="59" cy="33" r=".22" fill="currentColor"/>
  <circle cx="60" cy="33" r=".22" fill="currentColor"/>
  <circle cx="61" cy="33" r=".22" fill="currentColor"/>
  <circle cx="62" cy="33" r=".22" fill="currentColor"/>
  <circle cx="63" cy="33" r=".22" fill="currentColor"/>
  <circle cx="64" cy="33" r=".22" fill="currentColor"/>
  <circle cx="65" cy="33" r=".22" fill="currentColor"/>
  <circle cx="66" cy="33" r=".22" fill="currentColor"/>
  <circle cx="67" cy="33" r=".22" fill="currentColor"/>
  <circle cx="68" cy="33" r=".22" fill="currentColor"/>
  <circle cx="69" cy="33" r=".22" fill="currentColor"/>
  <circle cx="70" cy="33" r=".22" fill="currentColor"/>
  <circle cx="71" cy="33" r=".22" fill="currentColor"/>
  <circle cx="72" cy="33" r=".22" fill="currentColor"/>
  <circle cx="73" cy="33" r=".22" fill="currentColor"/>
  <circle cx="74" cy="33" r=".22" fill="currentColor"/>
  <circle cx="75" cy="33" r=".22" fill="currentColor"/>
  <circle cx="76" cy="33" r=".22" fill="currentColor"/>
  <circle cx="77" cy="33" r=".22" fill="currentColor"/>
  <circle cx="78" cy="33" r=".22" fill="currentColor"/>
  <circle cx="79" cy="33" r=".22" fill="currentColor"/>
  <circle cx="80" cy="33" r=".22" fill="currentColor"/>
  <circle cx="98" cy="33" r=".22" fill="currentColor"/>
  <circle cx="100" cy="33" r=".22" fill="currentColor"/>
  <circle cx="107" cy="33" r=".22" fill="currentColor"/>
  <circle cx="36" cy="34" r=".22" fill="currentColor"/>
  <circle cx="37" cy="34" r=".22" fill="currentColor"/>
  <circle cx="38" cy="34" r=".22" fill="currentColor"/>
  <circle cx="39" cy="34" r=".22" fill="currentColor"/>
  <circle cx="40" cy="34" r=".22" fill="currentColor"/>
  <circle cx="41" cy="34" r=".22" fill="currentColor"/>
  <circle cx="42" cy="34" r=".22" fill="currentColor"/>
  <circle cx="43" cy="34" r=".22" fill="currentColor"/>
  <circle cx="60" cy="34" r=".22" fill="currentColor"/>
  <circle cx="61" cy="34" r=".22" fill="currentColor"/>
  <circle cx="62" cy="34" r=".22" fill="currentColor"/>
  <circle cx="63" cy="34" r=".22" fill="currentColor"/>
  <circle cx="65" cy="34" r=".22" fill="currentColor"/>
  <circle cx="66" cy="34" r=".22" fill="currentColor"/>
  <circle cx="67" cy="34" r=".22" fill="currentColor"/>
  <circle cx="68" cy="34" r=".22" fill="currentColor"/>
  <circle cx="69" cy="34" r=".22" fill="currentColor"/>
  <circle cx="70" cy="34" r=".22" fill="currentColor"/>
  <circle cx="71" cy="34" r=".22" fill="currentColor"/>
  <circle cx="72" cy="34" r=".22" fill="currentColor"/>
  <circle cx="73" cy="34" r=".22" fill="currentColor"/>
  <circle cx="74" cy="34" r=".22" fill="currentColor"/>
  <circle cx="75" cy="34" r=".22" fill="currentColor"/>
  <circle cx="76" cy="34" r=".22" fill="currentColor"/>
  <circle cx="77" cy="34" r=".22" fill="currentColor"/>
  <circle cx="78" cy="34" r=".22" fill="currentColor"/>
  <circle cx="79" cy="34" r=".22" fill="currentColor"/>
  <circle cx="80" cy="34" r=".22" fill="currentColor"/>
  <circle cx="99" cy="34" r=".22" fill="currentColor"/>
  <circle cx="104" cy="34" r=".22" fill="currentColor"/>
  <circle cx="107" cy="34" r=".22" fill="currentColor"/>
  <circle cx="36" cy="35" r=".22" fill="currentColor"/>
  <circle cx="37" cy="35" r=".22" fill="currentColor"/>
  <circle cx="38" cy="35" r=".22" fill="currentColor"/>
  <circle cx="39" cy="35" r=".22" fill="currentColor"/>
  <circle cx="40" cy="35" r=".22" fill="currentColor"/>
  <circle cx="41" cy="35" r=".22" fill="currentColor"/>
  <circle cx="42" cy="35" r=".22" fill="currentColor"/>
  <circle cx="43" cy="35" r=".22" fill="currentColor"/>
  <circle cx="44" cy="35" r=".22" fill="currentColor"/>
  <circle cx="45" cy="35" r=".22" fill="currentColor"/>
  <circle cx="67" cy="35" r=".22" fill="currentColor"/>
  <circle cx="68" cy="35" r=".22" fill="currentColor"/>
  <circle cx="69" cy="35" r=".22" fill="currentColor"/>
  <circle cx="70" cy="35" r=".22" fill="currentColor"/>
  <circle cx="71" cy="35" r=".22" fill="currentColor"/>
  <circle cx="72" cy="35" r=".22" fill="currentColor"/>
  <circle cx="73" cy="35" r=".22" fill="currentColor"/>
  <circle cx="74" cy="35" r=".22" fill="currentColor"/>
  <circle cx="75" cy="35" r=".22" fill="currentColor"/>
  <circle cx="76" cy="35" r=".22" fill="currentColor"/>
  <circle cx="77" cy="35" r=".22" fill="currentColor"/>
  <circle cx="78" cy="35" r=".22" fill="currentColor"/>
  <circle cx="79" cy="35" r=".22" fill="currentColor"/>
  <circle cx="98" cy="35" r=".22" fill="currentColor"/>
  <circle cx="99" cy="35" r=".22" fill="currentColor"/>
  <circle cx="103" cy="35" r=".22" fill="currentColor"/>
  <circle cx="104" cy="35" r=".22" fill="currentColor"/>
  <circle cx="35" cy="36" r=".22" fill="currentColor"/>
  <circle cx="36" cy="36" r=".22" fill="currentColor"/>
  <circle cx="37" cy="36" r=".22" fill="currentColor"/>
  <circle cx="38" cy="36" r=".22" fill="currentColor"/>
  <circle cx="39" cy="36" r=".22" fill="currentColor"/>
  <circle cx="40" cy="36" r=".22" fill="currentColor"/>
  <circle cx="41" cy="36" r=".22" fill="currentColor"/>
  <circle cx="42" cy="36" r=".22" fill="currentColor"/>
  <circle cx="43" cy="36" r=".22" fill="currentColor"/>
  <circle cx="44" cy="36" r=".22" fill="currentColor"/>
  <circle cx="45" cy="36" r=".22" fill="currentColor"/>
  <circle cx="67" cy="36" r=".22" fill="currentColor"/>
  <circle cx="68" cy="36" r=".22" fill="currentColor"/>
  <circle cx="69" cy="36" r=".22" fill="currentColor"/>
  <circle cx="70" cy="36" r=".22" fill="currentColor"/>
  <circle cx="71" cy="36" r=".22" fill="currentColor"/>
  <circle cx="72" cy="36" r=".22" fill="currentColor"/>
  <circle cx="73" cy="36" r=".22" fill="currentColor"/>
  <circle cx="74" cy="36" r=".22" fill="currentColor"/>
  <circle cx="75" cy="36" r=".22" fill="currentColor"/>
  <circle cx="76" cy="36" r=".22" fill="currentColor"/>
  <circle cx="77" cy="36" r=".22" fill="currentColor"/>
  <circle cx="78" cy="36" r=".22" fill="currentColor"/>
  <circle cx="98" cy="36" r=".22" fill="currentColor"/>
  <circle cx="99" cy="36" r=".22" fill="currentColor"/>
  <circle cx="102" cy="36" r=".22" fill="currentColor"/>
  <circle cx="103" cy="36" r=".22" fill="currentColor"/>
  <circle cx="104" cy="36" r=".22" fill="currentColor"/>
  <circle cx="108" cy="36" r=".22" fill="currentColor"/>
  <circle cx="35" cy="37" r=".22" fill="currentColor"/>
  <circle cx="36" cy="37" r=".22" fill="currentColor"/>
  <circle cx="37" cy="37" r=".22" fill="currentColor"/>
  <circle cx="38" cy="37" r=".22" fill="currentColor"/>
  <circle cx="39" cy="37" r=".22" fill="currentColor"/>
  <circle cx="40" cy="37" r=".22" fill="currentColor"/>
  <circle cx="41" cy="37" r=".22" fill="currentColor"/>
  <circle cx="42" cy="37" r=".22" fill="currentColor"/>
  <circle cx="43" cy="37" r=".22" fill="currentColor"/>
  <circle cx="44" cy="37" r=".22" fill="currentColor"/>
  <circle cx="45" cy="37" r=".22" fill="currentColor"/>
  <circle cx="46" cy="37" r=".22" fill="currentColor"/>
  <circle cx="47" cy="37" r=".22" fill="currentColor"/>
  <circle cx="48" cy="37" r=".22" fill="currentColor"/>
  <circle cx="67" cy="37" r=".22" fill="currentColor"/>
  <circle cx="68" cy="37" r=".22" fill="currentColor"/>
  <circle cx="69" cy="37" r=".22" fill="currentColor"/>
  <circle cx="70" cy="37" r=".22" fill="currentColor"/>
  <circle cx="71" cy="37" r=".22" fill="currentColor"/>
  <circle cx="72" cy="37" r=".22" fill="currentColor"/>
  <circle cx="73" cy="37" r=".22" fill="currentColor"/>
  <circle cx="74" cy="37" r=".22" fill="currentColor"/>
  <circle cx="75" cy="37" r=".22" fill="currentColor"/>
  <circle cx="76" cy="37" r=".22" fill="currentColor"/>
  <circle cx="77" cy="37" r=".22" fill="currentColor"/>
  <circle cx="99" cy="37" r=".22" fill="currentColor"/>
  <circle cx="100" cy="37" r=".22" fill="currentColor"/>
  <circle cx="102" cy="37" r=".22" fill="currentColor"/>
  <circle cx="103" cy="37" r=".22" fill="currentColor"/>
  <circle cx="104" cy="37" r=".22" fill="currentColor"/>
  <circle cx="105" cy="37" r=".22" fill="currentColor"/>
  <circle cx="110" cy="37" r=".22" fill="currentColor"/>
  <circle cx="111" cy="37" r=".22" fill="currentColor"/>
  <circle cx="112" cy="37" r=".22" fill="currentColor"/>
  <circle cx="35" cy="38" r=".22" fill="currentColor"/>
  <circle cx="36" cy="38" r=".22" fill="currentColor"/>
  <circle cx="37" cy="38" r=".22" fill="currentColor"/>
  <circle cx="38" cy="38" r=".22" fill="currentColor"/>
  <circle cx="39" cy="38" r=".22" fill="currentColor"/>
  <circle cx="40" cy="38" r=".22" fill="currentColor"/>
  <circle cx="41" cy="38" r=".22" fill="currentColor"/>
  <circle cx="42" cy="38" r=".22" fill="currentColor"/>
  <circle cx="43" cy="38" r=".22" fill="currentColor"/>
  <circle cx="44" cy="38" r=".22" fill="currentColor"/>
  <circle cx="45" cy="38" r=".22" fill="currentColor"/>
  <circle cx="46" cy="38" r=".22" fill="currentColor"/>
  <circle cx="47" cy="38" r=".22" fill="currentColor"/>
  <circle cx="48" cy="38" r=".22" fill="currentColor"/>
  <circle cx="49" cy="38" r=".22" fill="currentColor"/>
  <circle cx="50" cy="38" r=".22" fill="currentColor"/>
  <circle cx="68" cy="38" r=".22" fill="currentColor"/>
  <circle cx="69" cy="38" r=".22" fill="currentColor"/>
  <circle cx="70" cy="38" r=".22" fill="currentColor"/>
  <circle cx="71" cy="38" r=".22" fill="currentColor"/>
  <circle cx="72" cy="38" r=".22" fill="currentColor"/>
  <circle cx="73" cy="38" r=".22" fill="currentColor"/>
  <circle cx="74" cy="38" r=".22" fill="currentColor"/>
  <circle cx="75" cy="38" r=".22" fill="currentColor"/>
  <circle cx="76" cy="38" r=".22" fill="currentColor"/>
  <circle cx="100" cy="38" r=".22" fill="currentColor"/>
  <circle cx="112" cy="38" r=".22" fill="currentColor"/>
  <circle cx="113" cy="38" r=".22" fill="currentColor"/>
  <circle cx="114" cy="38" r=".22" fill="currentColor"/>
  <circle cx="36" cy="39" r=".22" fill="currentColor"/>
  <circle cx="37" cy="39" r=".22" fill="currentColor"/>
  <circle cx="38" cy="39" r=".22" fill="currentColor"/>
  <circle cx="39" cy="39" r=".22" fill="currentColor"/>
  <circle cx="40" cy="39" r=".22" fill="currentColor"/>
  <circle cx="41" cy="39" r=".22" fill="currentColor"/>
  <circle cx="42" cy="39" r=".22" fill="currentColor"/>
  <circle cx="43" cy="39" r=".22" fill="currentColor"/>
  <circle cx="44" cy="39" r=".22" fill="currentColor"/>
  <circle cx="45" cy="39" r=".22" fill="currentColor"/>
  <circle cx="46" cy="39" r=".22" fill="currentColor"/>
  <circle cx="47" cy="39" r=".22" fill="currentColor"/>
  <circle cx="48" cy="39" r=".22" fill="currentColor"/>
  <circle cx="49" cy="39" r=".22" fill="currentColor"/>
  <circle cx="50" cy="39" r=".22" fill="currentColor"/>
  <circle cx="68" cy="39" r=".22" fill="currentColor"/>
  <circle cx="69" cy="39" r=".22" fill="currentColor"/>
  <circle cx="70" cy="39" r=".22" fill="currentColor"/>
  <circle cx="71" cy="39" r=".22" fill="currentColor"/>
  <circle cx="72" cy="39" r=".22" fill="currentColor"/>
  <circle cx="73" cy="39" r=".22" fill="currentColor"/>
  <circle cx="74" cy="39" r=".22" fill="currentColor"/>
  <circle cx="75" cy="39" r=".22" fill="currentColor"/>
  <circle cx="76" cy="39" r=".22" fill="currentColor"/>
  <circle cx="103" cy="39" r=".22" fill="currentColor"/>
  <circle cx="113" cy="39" r=".22" fill="currentColor"/>
  <circle cx="115" cy="39" r=".22" fill="currentColor"/>
  <circle cx="36" cy="40" r=".22" fill="currentColor"/>
  <circle cx="37" cy="40" r=".22" fill="currentColor"/>
  <circle cx="38" cy="40" r=".22" fill="currentColor"/>
  <circle cx="39" cy="40" r=".22" fill="currentColor"/>
  <circle cx="40" cy="40" r=".22" fill="currentColor"/>
  <circle cx="41" cy="40" r=".22" fill="currentColor"/>
  <circle cx="42" cy="40" r=".22" fill="currentColor"/>
  <circle cx="43" cy="40" r=".22" fill="currentColor"/>
  <circle cx="44" cy="40" r=".22" fill="currentColor"/>
  <circle cx="45" cy="40" r=".22" fill="currentColor"/>
  <circle cx="46" cy="40" r=".22" fill="currentColor"/>
  <circle cx="47" cy="40" r=".22" fill="currentColor"/>
  <circle cx="48" cy="40" r=".22" fill="currentColor"/>
  <circle cx="49" cy="40" r=".22" fill="currentColor"/>
  <circle cx="68" cy="40" r=".22" fill="currentColor"/>
  <circle cx="69" cy="40" r=".22" fill="currentColor"/>
  <circle cx="70" cy="40" r=".22" fill="currentColor"/>
  <circle cx="71" cy="40" r=".22" fill="currentColor"/>
  <circle cx="72" cy="40" r=".22" fill="currentColor"/>
  <circle cx="73" cy="40" r=".22" fill="currentColor"/>
  <circle cx="74" cy="40" r=".22" fill="currentColor"/>
  <circle cx="75" cy="40" r=".22" fill="currentColor"/>
  <circle cx="76" cy="40" r=".22" fill="currentColor"/>
  <circle cx="77" cy="40" r=".22" fill="currentColor"/>
  <circle cx="37" cy="41" r=".22" fill="currentColor"/>
  <circle cx="38" cy="41" r=".22" fill="currentColor"/>
  <circle cx="39" cy="41" r=".22" fill="currentColor"/>
  <circle cx="40" cy="41" r=".22" fill="currentColor"/>
  <circle cx="41" cy="41" r=".22" fill="currentColor"/>
  <circle cx="42" cy="41" r=".22" fill="currentColor"/>
  <circle cx="43" cy="41" r=".22" fill="currentColor"/>
  <circle cx="44" cy="41" r=".22" fill="currentColor"/>
  <circle cx="45" cy="41" r=".22" fill="currentColor"/>
  <circle cx="46" cy="41" r=".22" fill="currentColor"/>
  <circle cx="47" cy="41" r=".22" fill="currentColor"/>
  <circle cx="48" cy="41" r=".22" fill="currentColor"/>
  <circle cx="49" cy="41" r=".22" fill="currentColor"/>
  <circle cx="68" cy="41" r=".22" fill="currentColor"/>
  <circle cx="69" cy="41" r=".22" fill="currentColor"/>
  <circle cx="70" cy="41" r=".22" fill="currentColor"/>
  <circle cx="71" cy="41" r=".22" fill="currentColor"/>
  <circle cx="72" cy="41" r=".22" fill="currentColor"/>
  <circle cx="73" cy="41" r=".22" fill="currentColor"/>
  <circle cx="74" cy="41" r=".22" fill="currentColor"/>
  <circle cx="75" cy="41" r=".22" fill="currentColor"/>
  <circle cx="76" cy="41" r=".22" fill="currentColor"/>
  <circle cx="77" cy="41" r=".22" fill="currentColor"/>
  <circle cx="80" cy="41" r=".22" fill="currentColor"/>
  <circle cx="109" cy="41" r=".22" fill="currentColor"/>
  <circle cx="110" cy="41" r=".22" fill="currentColor"/>
  <circle cx="113" cy="41" r=".22" fill="currentColor"/>
  <circle cx="38" cy="42" r=".22" fill="currentColor"/>
  <circle cx="39" cy="42" r=".22" fill="currentColor"/>
  <circle cx="40" cy="42" r=".22" fill="currentColor"/>
  <circle cx="41" cy="42" r=".22" fill="currentColor"/>
  <circle cx="42" cy="42" r=".22" fill="currentColor"/>
  <circle cx="43" cy="42" r=".22" fill="currentColor"/>
  <circle cx="44" cy="42" r=".22" fill="currentColor"/>
  <circle cx="45" cy="42" r=".22" fill="currentColor"/>
  <circle cx="46" cy="42" r=".22" fill="currentColor"/>
  <circle cx="47" cy="42" r=".22" fill="currentColor"/>
  <circle cx="48" cy="42" r=".22" fill="currentColor"/>
  <circle cx="49" cy="42" r=".22" fill="currentColor"/>
  <circle cx="68" cy="42" r=".22" fill="currentColor"/>
  <circle cx="69" cy="42" r=".22" fill="currentColor"/>
  <circle cx="70" cy="42" r=".22" fill="currentColor"/>
  <circle cx="71" cy="42" r=".22" fill="currentColor"/>
  <circle cx="72" cy="42" r=".22" fill="currentColor"/>
  <circle cx="73" cy="42" r=".22" fill="currentColor"/>
  <circle cx="74" cy="42" r=".22" fill="currentColor"/>
  <circle cx="75" cy="42" r=".22" fill="currentColor"/>
  <circle cx="76" cy="42" r=".22" fill="currentColor"/>
  <circle cx="79" cy="42" r=".22" fill="currentColor"/>
  <circle cx="80" cy="42" r=".22" fill="currentColor"/>
  <circle cx="107" cy="42" r=".22" fill="currentColor"/>
  <circle cx="108" cy="42" r=".22" fill="currentColor"/>
  <circle cx="109" cy="42" r=".22" fill="currentColor"/>
  <circle cx="110" cy="42" r=".22" fill="currentColor"/>
  <circle cx="111" cy="42" r=".22" fill="currentColor"/>
  <circle cx="113" cy="42" r=".22" fill="currentColor"/>
  <circle cx="114" cy="42" r=".22" fill="currentColor"/>
  <circle cx="39" cy="43" r=".22" fill="currentColor"/>
  <circle cx="40" cy="43" r=".22" fill="currentColor"/>
  <circle cx="41" cy="43" r=".22" fill="currentColor"/>
  <circle cx="42" cy="43" r=".22" fill="currentColor"/>
  <circle cx="43" cy="43" r=".22" fill="currentColor"/>
  <circle cx="44" cy="43" r=".22" fill="currentColor"/>
  <circle cx="45" cy="43" r=".22" fill="currentColor"/>
  <circle cx="46" cy="43" r=".22" fill="currentColor"/>
  <circle cx="47" cy="43" r=".22" fill="currentColor"/>
  <circle cx="48" cy="43" r=".22" fill="currentColor"/>
  <circle cx="49" cy="43" r=".22" fill="currentColor"/>
  <circle cx="68" cy="43" r=".22" fill="currentColor"/>
  <circle cx="69" cy="43" r=".22" fill="currentColor"/>
  <circle cx="70" cy="43" r=".22" fill="currentColor"/>
  <circle cx="71" cy="43" r=".22" fill="currentColor"/>
  <circle cx="72" cy="43" r=".22" fill="currentColor"/>
  <circle cx="73" cy="43" r=".22" fill="currentColor"/>
  <circle cx="74" cy="43" r=".22" fill="currentColor"/>
  <circle cx="75" cy="43" r=".22" fill="currentColor"/>
  <circle cx="79" cy="43" r=".22" fill="currentColor"/>
  <circle cx="80" cy="43" r=".22" fill="currentColor"/>
  <circle cx="106" cy="43" r=".22" fill="currentColor"/>
  <circle cx="107" cy="43" r=".22" fill="currentColor"/>
  <circle cx="108" cy="43" r=".22" fill="currentColor"/>
  <circle cx="109" cy="43" r=".22" fill="currentColor"/>
  <circle cx="110" cy="43" r=".22" fill="currentColor"/>
  <circle cx="111" cy="43" r=".22" fill="currentColor"/>
  <circle cx="112" cy="43" r=".22" fill="currentColor"/>
  <circle cx="113" cy="43" r=".22" fill="currentColor"/>
  <circle cx="114" cy="43" r=".22" fill="currentColor"/>
  <circle cx="39" cy="44" r=".22" fill="currentColor"/>
  <circle cx="40" cy="44" r=".22" fill="currentColor"/>
  <circle cx="41" cy="44" r=".22" fill="currentColor"/>
  <circle cx="42" cy="44" r=".22" fill="currentColor"/>
  <circle cx="43" cy="44" r=".22" fill="currentColor"/>
  <circle cx="44" cy="44" r=".22" fill="currentColor"/>
  <circle cx="45" cy="44" r=".22" fill="currentColor"/>
  <circle cx="46" cy="44" r=".22" fill="currentColor"/>
  <circle cx="47" cy="44" r=".22" fill="currentColor"/>
  <circle cx="48" cy="44" r=".22" fill="currentColor"/>
  <circle cx="68" cy="44" r=".22" fill="currentColor"/>
  <circle cx="69" cy="44" r=".22" fill="currentColor"/>
  <circle cx="70" cy="44" r=".22" fill="currentColor"/>
  <circle cx="71" cy="44" r=".22" fill="currentColor"/>
  <circle cx="72" cy="44" r=".22" fill="currentColor"/>
  <circle cx="73" cy="44" r=".22" fill="currentColor"/>
  <circle cx="74" cy="44" r=".22" fill="currentColor"/>
  <circle cx="75" cy="44" r=".22" fill="currentColor"/>
  <circle cx="79" cy="44" r=".22" fill="currentColor"/>
  <circle cx="104" cy="44" r=".22" fill="currentColor"/>
  <circle cx="105" cy="44" r=".22" fill="currentColor"/>
  <circle cx="106" cy="44" r=".22" fill="currentColor"/>
  <circle cx="107" cy="44" r=".22" fill="currentColor"/>
  <circle cx="108" cy="44" r=".22" fill="currentColor"/>
  <circle cx="109" cy="44" r=".22" fill="currentColor"/>
  <circle cx="110" cy="44" r=".22" fill="currentColor"/>
  <circle cx="111" cy="44" r=".22" fill="currentColor"/>
  <circle cx="112" cy="44" r=".22" fill="currentColor"/>
  <circle cx="113" cy="44" r=".22" fill="currentColor"/>
  <circle cx="114" cy="44" r=".22" fill="currentColor"/>
  <circle cx="115" cy="44" r=".22" fill="currentColor"/>
  <circle cx="39" cy="45" r=".22" fill="currentColor"/>
  <circle cx="40" cy="45" r=".22" fill="currentColor"/>
  <circle cx="41" cy="45" r=".22" fill="currentColor"/>
  <circle cx="42" cy="45" r=".22" fill="currentColor"/>
  <circle cx="43" cy="45" r=".22" fill="currentColor"/>
  <circle cx="44" cy="45" r=".22" fill="currentColor"/>
  <circle cx="45" cy="45" r=".22" fill="currentColor"/>
  <circle cx="46" cy="45" r=".22" fill="currentColor"/>
  <circle cx="69" cy="45" r=".22" fill="currentColor"/>
  <circle cx="70" cy="45" r=".22" fill="currentColor"/>
  <circle cx="71" cy="45" r=".22" fill="currentColor"/>
  <circle cx="72" cy="45" r=".22" fill="currentColor"/>
  <circle cx="73" cy="45" r=".22" fill="currentColor"/>
  <circle cx="74" cy="45" r=".22" fill="currentColor"/>
  <circle cx="75" cy="45" r=".22" fill="currentColor"/>
  <circle cx="79" cy="45" r=".22" fill="currentColor"/>
  <circle cx="103" cy="45" r=".22" fill="currentColor"/>
  <circle cx="104" cy="45" r=".22" fill="currentColor"/>
  <circle cx="105" cy="45" r=".22" fill="currentColor"/>
  <circle cx="106" cy="45" r=".22" fill="currentColor"/>
  <circle cx="107" cy="45" r=".22" fill="currentColor"/>
  <circle cx="108" cy="45" r=".22" fill="currentColor"/>
  <circle cx="109" cy="45" r=".22" fill="currentColor"/>
  <circle cx="110" cy="45" r=".22" fill="currentColor"/>
  <circle cx="111" cy="45" r=".22" fill="currentColor"/>
  <circle cx="112" cy="45" r=".22" fill="currentColor"/>
  <circle cx="113" cy="45" r=".22" fill="currentColor"/>
  <circle cx="114" cy="45" r=".22" fill="currentColor"/>
  <circle cx="115" cy="45" r=".22" fill="currentColor"/>
  <circle cx="116" cy="45" r=".22" fill="currentColor"/>
  <circle cx="39" cy="46" r=".22" fill="currentColor"/>
  <circle cx="40" cy="46" r=".22" fill="currentColor"/>
  <circle cx="41" cy="46" r=".22" fill="currentColor"/>
  <circle cx="42" cy="46" r=".22" fill="currentColor"/>
  <circle cx="43" cy="46" r=".22" fill="currentColor"/>
  <circle cx="44" cy="46" r=".22" fill="currentColor"/>
  <circle cx="45" cy="46" r=".22" fill="currentColor"/>
  <circle cx="69" cy="46" r=".22" fill="currentColor"/>
  <circle cx="70" cy="46" r=".22" fill="currentColor"/>
  <circle cx="71" cy="46" r=".22" fill="currentColor"/>
  <circle cx="72" cy="46" r=".22" fill="currentColor"/>
  <circle cx="73" cy="46" r=".22" fill="currentColor"/>
  <circle cx="74" cy="46" r=".22" fill="currentColor"/>
  <circle cx="104" cy="46" r=".22" fill="currentColor"/>
  <circle cx="105" cy="46" r=".22" fill="currentColor"/>
  <circle cx="106" cy="46" r=".22" fill="currentColor"/>
  <circle cx="107" cy="46" r=".22" fill="currentColor"/>
  <circle cx="108" cy="46" r=".22" fill="currentColor"/>
  <circle cx="109" cy="46" r=".22" fill="currentColor"/>
  <circle cx="110" cy="46" r=".22" fill="currentColor"/>
  <circle cx="111" cy="46" r=".22" fill="currentColor"/>
  <circle cx="112" cy="46" r=".22" fill="currentColor"/>
  <circle cx="113" cy="46" r=".22" fill="currentColor"/>
  <circle cx="114" cy="46" r=".22" fill="currentColor"/>
  <circle cx="115" cy="46" r=".22" fill="currentColor"/>
  <circle cx="116" cy="46" r=".22" fill="currentColor"/>
  <circle cx="38" cy="47" r=".22" fill="currentColor"/>
  <circle cx="39" cy="47" r=".22" fill="currentColor"/>
  <circle cx="40" cy="47" r=".22" fill="currentColor"/>
  <circle cx="41" cy="47" r=".22" fill="currentColor"/>
  <circle cx="42" cy="47" r=".22" fill="currentColor"/>
  <circle cx="43" cy="47" r=".22" fill="currentColor"/>
  <circle cx="44" cy="47" r=".22" fill="currentColor"/>
  <circle cx="45" cy="47" r=".22" fill="currentColor"/>
  <circle cx="69" cy="47" r=".22" fill="currentColor"/>
  <circle cx="70" cy="47" r=".22" fill="currentColor"/>
  <circle cx="71" cy="47" r=".22" fill="currentColor"/>
  <circle cx="72" cy="47" r=".22" fill="currentColor"/>
  <circle cx="73" cy="47" r=".22" fill="currentColor"/>
  <circle cx="104" cy="47" r=".22" fill="currentColor"/>
  <circle cx="105" cy="47" r=".22" fill="currentColor"/>
  <circle cx="106" cy="47" r=".22" fill="currentColor"/>
  <circle cx="107" cy="47" r=".22" fill="currentColor"/>
  <circle cx="108" cy="47" r=".22" fill="currentColor"/>
  <circle cx="109" cy="47" r=".22" fill="currentColor"/>
  <circle cx="110" cy="47" r=".22" fill="currentColor"/>
  <circle cx="111" cy="47" r=".22" fill="currentColor"/>
  <circle cx="112" cy="47" r=".22" fill="currentColor"/>
  <circle cx="113" cy="47" r=".22" fill="currentColor"/>
  <circle cx="114" cy="47" r=".22" fill="currentColor"/>
  <circle cx="115" cy="47" r=".22" fill="currentColor"/>
  <circle cx="116" cy="47" r=".22" fill="currentColor"/>
  <circle cx="38" cy="48" r=".22" fill="currentColor"/>
  <circle cx="39" cy="48" r=".22" fill="currentColor"/>
  <circle cx="40" cy="48" r=".22" fill="currentColor"/>
  <circle cx="41" cy="48" r=".22" fill="currentColor"/>
  <circle cx="42" cy="48" r=".22" fill="currentColor"/>
  <circle cx="43" cy="48" r=".22" fill="currentColor"/>
  <circle cx="44" cy="48" r=".22" fill="currentColor"/>
  <circle cx="70" cy="48" r=".22" fill="currentColor"/>
  <circle cx="71" cy="48" r=".22" fill="currentColor"/>
  <circle cx="72" cy="48" r=".22" fill="currentColor"/>
  <circle cx="73" cy="48" r=".22" fill="currentColor"/>
  <circle cx="104" cy="48" r=".22" fill="currentColor"/>
  <circle cx="105" cy="48" r=".22" fill="currentColor"/>
  <circle cx="106" cy="48" r=".22" fill="currentColor"/>
  <circle cx="107" cy="48" r=".22" fill="currentColor"/>
  <circle cx="108" cy="48" r=".22" fill="currentColor"/>
  <circle cx="110" cy="48" r=".22" fill="currentColor"/>
  <circle cx="111" cy="48" r=".22" fill="currentColor"/>
  <circle cx="112" cy="48" r=".22" fill="currentColor"/>
  <circle cx="113" cy="48" r=".22" fill="currentColor"/>
  <circle cx="114" cy="48" r=".22" fill="currentColor"/>
  <circle cx="115" cy="48" r=".22" fill="currentColor"/>
  <circle cx="116" cy="48" r=".22" fill="currentColor"/>
  <circle cx="38" cy="49" r=".22" fill="currentColor"/>
  <circle cx="39" cy="49" r=".22" fill="currentColor"/>
  <circle cx="40" cy="49" r=".22" fill="currentColor"/>
  <circle cx="41" cy="49" r=".22" fill="currentColor"/>
  <circle cx="42" cy="49" r=".22" fill="currentColor"/>
  <circle cx="43" cy="49" r=".22" fill="currentColor"/>
  <circle cx="44" cy="49" r=".22" fill="currentColor"/>
  <circle cx="70" cy="49" r=".22" fill="currentColor"/>
  <circle cx="104" cy="49" r=".22" fill="currentColor"/>
  <circle cx="105" cy="49" r=".22" fill="currentColor"/>
  <circle cx="112" cy="49" r=".22" fill="currentColor"/>
  <circle cx="113" cy="49" r=".22" fill="currentColor"/>
  <circle cx="114" cy="49" r=".22" fill="currentColor"/>
  <circle cx="115" cy="49" r=".22" fill="currentColor"/>
  <circle cx="38" cy="50" r=".22" fill="currentColor"/>
  <circle cx="39" cy="50" r=".22" fill="currentColor"/>
  <circle cx="40" cy="50" r=".22" fill="currentColor"/>
  <circle cx="41" cy="50" r=".22" fill="currentColor"/>
  <circle cx="42" cy="50" r=".22" fill="currentColor"/>
  <circle cx="43" cy="50" r=".22" fill="currentColor"/>
  <circle cx="113" cy="50" r=".22" fill="currentColor"/>
  <circle cx="114" cy="50" r=".22" fill="currentColor"/>
  <circle cx="115" cy="50" r=".22" fill="currentColor"/>
  <circle cx="38" cy="51" r=".22" fill="currentColor"/>
  <circle cx="39" cy="51" r=".22" fill="currentColor"/>
  <circle cx="40" cy="51" r=".22" fill="currentColor"/>
  <circle cx="41" cy="51" r=".22" fill="currentColor"/>
  
  <circle cx="37" cy="52" r=".22" fill="currentColor"/>
  <circle cx="38" cy="52" r=".22" fill="currentColor"/>
  <circle cx="39" cy="52" r=".22" fill="currentColor"/>
  <circle cx="40" cy="52" r=".22" fill="currentColor"/>
  <circle cx="114" cy="52" r=".22" fill="currentColor"/>
  <circle cx="115" cy="52" r=".22" fill="currentColor"/>
  <circle cx="37" cy="53" r=".22" fill="currentColor"/>
  <circle cx="38" cy="53" r=".22" fill="currentColor"/>
  <circle cx="39" cy="53" r=".22" fill="currentColor"/>
  <circle cx="40" cy="53" r=".22" fill="currentColor"/>
  
  <circle cx="37" cy="54" r=".22" fill="currentColor"/>
  <circle cx="38" cy="54" r=".22" fill="currentColor"/>
  <circle cx="39" cy="54" r=".22" fill="currentColor"/>
  
  
  <circle cx="37" cy="55" r=".22" fill="currentColor"/>
  <circle cx="38" cy="55" r=".22" fill="currentColor"/>
  <circle cx="39" cy="55" r=".22" fill="currentColor"/>
  <circle cx="37" cy="56" r=".22" fill="currentColor"/>
  <circle cx="38" cy="56" r=".22" fill="currentColor"/>
  <circle cx="39" cy="56" r=".22" fill="currentColor"/>
  <circle cx="37" cy="57" r=".22" fill="currentColor"/>
  <circle cx="38" cy="57" r=".22" fill="currentColor"/>
  <circle cx="37" cy="58" r=".22" fill="currentColor"/>
  <circle cx="38" cy="58" r=".22" fill="currentColor"/>
  <circle cx="38" cy="59" r=".22" fill="currentColor"/>
  <circle cx="39" cy="59" r=".22" fill="currentColor"/>

    </svg>

    <div class="rino-world-map-markers">
        @foreach ($mapLocations as $index => $item)
            @php
                if (
                    !is_array($item)
                    ||
                    !($item['enabled'] ?? true)
                ) {
                    continue;
                }

                $key =
                    $item['location']
                    ?? null;

                $preset =
                    $key
                        ? LocationPresets::get($key)
                        : null;

                if (!$preset) {
                    continue;
                }

                $left =
                    ($preset['x'] / LocationPresets::MAP_WIDTH)
                    * 100;

                $top =
                    ($preset['y'] / LocationPresets::MAP_HEIGHT)
                    * 100;

                $flag =
                    LocationPresets::flag($key);

                $country =
                    $preset['country'];

                $city =
                    $preset['city'];

                $popupId =
                    'rino-map-location-'
                    . ($item['id'] ?? $index);
            @endphp

            <div
                class="rino-world-marker"
                data-rino-map-marker
                style="
                    left: {{ $left }}%;
                    top: {{ $top }}%;
                "
            >
                <button
                    type="button"
                    class="rino-world-marker-button"
                    data-rino-map-marker-button
                    aria-expanded="false"
                    aria-controls="{{ $popupId }}"
                    aria-label="{{ $country }}, {{ $city }}"
                >
                    <span class="rino-world-marker-core"></span>
                </button>

                <div
                    id="{{ $popupId }}"
                    class="rino-world-marker-popover"
                    data-rino-map-marker-popover
                    hidden
                >
                    @if ($flag)
                        <img
                            src="{{ $flag }}"
                            alt=""
                            class="rino-world-marker-flag"
                        >
                    @endif

                    <div class="rino-world-marker-location">
                        {{ $country }}, {{ $city }}
                    </div>

                    <span
                        class="rino-world-marker-popover-arrow"
                        aria-hidden="true"
                    ></span>
                </div>
            </div>
        @endforeach
    </div>
</div>

<style>
    .rino-world-map {
        position: relative;
        width: 100%;
        aspect-ratio: 126 / 60;
        color:
            color-mix(
                in srgb,
                var(--border) 84%,
                var(--text-muted) 16%
            );
    }

    .rino-world-svg {
        display: block;
        width: 100%;
        height: 100%;
        overflow: visible;
    }

    .rino-world-svg circle {
        fill: currentColor;
    }

    .rino-world-map-markers {
        position: absolute;
        inset: 0;
        pointer-events: none;
    }

    .rino-world-marker {
        position: absolute;
        width: 0;
        height: 0;
        z-index: 10;
        pointer-events: auto;
    }

    .rino-world-marker-button {
        position: absolute;
        left: 0;
        top: 0;
        width: 14px;
        height: 14px;
        padding: 0;
        border: 1.5px solid var(--primary);
        border-radius: 9999px;
        background:
            color-mix(
                in srgb,
                var(--primary) 12%,
                var(--surface)
            );
        box-shadow:
            0 0 0 3px
            color-mix(
                in srgb,
                var(--primary) 16%,
                transparent
            );
        transform: translate(-50%, -50%);
        display: grid;
        place-items: center;
        cursor: pointer;
        transition:
            background 150ms ease,
            box-shadow 150ms ease;
    }

    .rino-world-marker-button:hover,
    .rino-world-marker-button:focus-visible,
    .rino-world-marker-button[aria-expanded="true"] {
        background:
            color-mix(
                in srgb,
                var(--primary) 20%,
                var(--surface)
            );
        box-shadow:
            0 0 0 4px
            color-mix(
                in srgb,
                var(--primary) 20%,
                transparent
            );
        outline: none;
    }

    .rino-world-marker-core {
        display: block;
        width: 6px;
        height: 6px;
        border-radius: 9999px;
        background: var(--primary);
    }

    .rino-world-marker-popover {
        position: absolute;
        left: 0;
        bottom: 12px;
        min-width: 168px;
        max-width: 240px;
        height: 40px;
        transform: translateX(-50%);
        border: 0;
        border-radius: 9999px;
        background: var(--surface-secondary);
        box-shadow: none;
        padding: 6px 9px;
        display: flex;
        align-items: center;
        gap: 8px;
        z-index: 30;
        white-space: nowrap;
    }

    .rino-world-marker-popover[hidden] {
        display: none;
    }

    .rino-world-marker-flag {
        width: 24px;
        height: 17px;
        flex: 0 0 auto;
        border-radius: 3px;
        object-fit: cover;
    }

    .rino-world-marker-location {
        min-width: 0;
        flex: 1 1 auto;
        overflow: hidden;
        text-overflow: ellipsis;
        font-size: 12px;
        line-height: 1;
        font-weight: 700;
        color: var(--text-heading);
    }


    .rino-world-marker-popover-arrow {
        position: absolute;
        left: 50%;
        bottom: -4px;
        width: 8px;
        height: 8px;
        transform:
            translateX(-50%)
            rotate(45deg);
        border: 0;
        background: var(--surface-secondary);
    }

    @media (max-width: 639px) {
        .rino-world-marker-button {
            width: 12px;
            height: 12px;
            box-shadow:
                0 0 0 2px
                color-mix(
                    in srgb,
                    var(--primary) 16%,
                    transparent
                );
        }

        .rino-world-marker-core {
            width: 5px;
            height: 5px;
        }

        .rino-world-marker-popover {
            min-width: 150px;
            max-width: 205px;
            height: 36px;
            padding: 5px 8px;
            gap: 7px;
        }

        .rino-world-marker-flag {
            width: 21px;
            height: 15px;
        }

        .rino-world-marker-location {
            font-size: 11px;
        }

    }
</style>

<script>
    (() => {
        const maps =
            document.querySelectorAll(
                '[data-rino-world-map]'
            );

        maps.forEach((map) => {
            if (
                map.dataset.rinoWorldMapReady ===
                'true'
            ) {
                return;
            }

            map.dataset.rinoWorldMapReady =
                'true';

            const markers =
                map.querySelectorAll(
                    '[data-rino-map-marker]'
                );

            const closeAll = (except = null) => {
                markers.forEach((marker) => {
                    if (marker === except) {
                        return;
                    }

                    const button =
                        marker.querySelector(
                            '[data-rino-map-marker-button]'
                        );

                    const popover =
                        marker.querySelector(
                            '[data-rino-map-marker-popover]'
                        );

                    if (!button || !popover) {
                        return;
                    }

                    button.setAttribute(
                        'aria-expanded',
                        'false'
                    );

                    popover.hidden = true;
                });
            };

            markers.forEach((marker) => {
                const button =
                    marker.querySelector(
                        '[data-rino-map-marker-button]'
                    );

                const popover =
                    marker.querySelector(
                        '[data-rino-map-marker-popover]'
                    );

                if (!button || !popover) {
                    return;
                }

                button.addEventListener(
                    'click',
                    (event) => {
                        event.stopPropagation();

                        const opening =
                            button.getAttribute(
                                'aria-expanded'
                            ) !== 'true';

                        closeAll(marker);

                        button.setAttribute(
                            'aria-expanded',
                            opening
                                ? 'true'
                                : 'false'
                        );

                        popover.hidden =
                            !opening;
                    }
                );

                popover.addEventListener(
                    'click',
                    (event) => {
                        event.stopPropagation();
                    }
                );
            });

            map.addEventListener(
                'click',
                () => {
                    closeAll();
                }
            );
        });
    })();
</script>

